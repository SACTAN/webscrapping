# 🔮 Comprehensive Self-Healing Selenium Framework

**Version:** 2.0.0 | **Java 11** | **Maven** | **Selenium 4.15** | **TestNG**

A **4-layer self-healing** test automation framework where each layer escalates to the next if healing fails.

---

## 🏗️ Architecture

```
Original Locator FAILS
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│  LAYER 1 — Cache & Quick Rules               ~100ms    │
│  ✓ Cache lookup (instant from previous runs)           │
│  ✓ Case variation: id → ID → Id                        │
│  ✓ Attribute swap: id→name→data-testid→aria-label      │
│  ✓ Locator type swap: xpath→id extraction              │
│  ✓ Version suffix strip: btn_v2 → btn                  │
│  ✓ Partial CSS: [id*='value'], [id^='value']           │
└───────────────────────┬─────────────────────────────────┘
                        │ FAIL ↓
┌─────────────────────────────────────────────────────────┐
│  LAYER 2 — Healenium ML Engine               2–5s      │
│  ✓ Longest Common Subsequence (LCS) algorithm          │
│  ✓ Tree Edit Distance (DOM structure similarity)       │
│  ✓ Weighted attribute scoring                          │
│  ✓ PostgreSQL-backed healing history & learning        │
│  ✓ Requires: docker-compose up -d                      │
└───────────────────────┬─────────────────────────────────┘
                        │ FAIL ↓
┌─────────────────────────────────────────────────────────┐
│  LAYER 3 — Advanced Fallback Engine          1–4s      │
│  ✓ Text-based search (exact + fuzzy + case-insensitive)│
│  ✓ Fuzzy LCS attribute match (all page elements)       │
│  ✓ Data-attribute: data-testid, data-cy, aria-label    │
│  ✓ Structural hierarchy: parent→child navigation       │
│  ✓ XPath simplification: strip indexes/predicates      │
│  ✓ Sibling-based: find near known stable sibling       │
│  ✓ Tag+class combination matching                      │
└───────────────────────┬─────────────────────────────────┘
                        │ FAIL ↓
┌─────────────────────────────────────────────────────────┐
│  LAYER 4 — Claude AI LLM (Final Safety Net)  3–15s    │
│  ✓ Sends full DOM context to Claude API                │
│  ✓ Claude analyzes page structure & suggests 5 locators│
│  ✓ Each candidate tried sequentially                   │
│  ✓ Successful result cached for future runs            │
│  ✓ Requires: ANTHROPIC_API_KEY environment variable    │
└───────────────────────┬─────────────────────────────────┘
                        │
              ✅ HEALED or ❌ Test Failure
```

---

## 📁 Project Structure

```
self-healing-framework/
├── src/main/java/com/healing/
│   ├── config/
│   │   └── HealingConfig.java          # Centralized configuration
│   ├── core/
│   │   ├── IHealingLayer.java          # Contract for all layers
│   │   ├── HybridHealingCoordinator.java # Master orchestrator
│   │   ├── SelfHealingWebDriver.java   # Main driver wrapper
│   │   └── HealingTestListener.java    # TestNG lifecycle listener
│   ├── layers/
│   │   ├── CacheAndRulesHealingLayer.java  # LAYER 1
│   │   ├── HealeniumMLHealingLayer.java    # LAYER 2
│   │   ├── AdvancedFallbackHealingLayer.java # LAYER 3
│   │   └── LLMAIHealingLayer.java          # LAYER 4
│   ├── models/
│   │   ├── HealingResult.java          # Result encapsulation
│   │   └── ElementContext.java         # Element context capture
│   ├── reporting/
│   │   └── HealingReporter.java        # HTML dashboard + JSON report
│   └── utils/
│       ├── DriverFactory.java          # Browser driver creation
│       ├── HealingCache.java           # Persistent cache
│       ├── LCSAlgorithm.java           # LCS similarity engine
│       └── ContextExtractor.java       # DOM context extraction
├── src/test/java/com/healing/tests/
│   ├── BaseTest.java                   # Abstract base (extend this)
│   ├── SelfHealingDemoTest.java        # Full demo test suite
│   └── HealingLayerUnitTest.java       # Unit tests (no browser)
├── src/main/resources/
│   ├── healing-config.properties       # Main config
│   └── logback.xml                     # Logging config
├── src/test/resources/
│   ├── healenium.properties            # Healenium Layer 2 config
│   └── testng.xml                      # TestNG suite
├── docker-compose.yml                  # Healenium backend services
└── pom.xml
```

---

## 🚀 Quick Start

### Prerequisites
- Java 11+
- Maven 3.9+
- Chrome browser
- Docker (for Layer 2 — optional but recommended)

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd self-healing-framework
mvn clean install -DskipTests
```

### 2. Start Healenium (Layer 2 — Optional)

```bash
docker-compose up -d
# Wait 60s for services to be ready
docker-compose ps    # Should show 3 services running
```

### 3. Configure Layer 4 AI (Optional but powerful)

```bash
# Set your Anthropic API key
export ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### 4. Run Tests

```bash
# Run all tests
mvn clean test

# Run only unit tests (no browser needed)
mvn test -Dtest=HealingLayerUnitTest

# Run demo tests
mvn test -Dtest=SelfHealingDemoTest

# Run headless
mvn test -Dheadless=true

# Run with specific browser
mvn test -Dbrowser=firefox
```

### 5. View Reports

After tests run, open the dashboard:
```
target/healing-reports/healing-dashboard-<timestamp>.html
target/healing-reports/healing-report-<timestamp>.json
target/healing-reports/healing.log
```

---

## 💻 Usage in Your Tests

```java
// Option 1: Extend BaseTest (recommended)
public class MyLoginTest extends BaseTest {

    @Test
    public void testLogin() {
        driver.get("https://myapp.com/login");

        // All findElement calls are automatically healed!
        driver.type(By.id("email"), "user@example.com");
        driver.type(By.id("password"), "secret");
        driver.click(By.id("submit-btn"));

        // If "submit-btn" changes to "login-btn", the framework heals it!
    }
}

// Option 2: Manual wrapping
WebDriver raw = new ChromeDriver();
SelfHealingWebDriver driver = SelfHealingWebDriver.wrap(raw);

// Option 3: Use DriverFactory
SelfHealingWebDriver driver = DriverFactory.createChromeDriver(true); // headless
SelfHealingWebDriver driver = DriverFactory.createFirefoxDriver();
```

---

## ⚙️ Configuration

Edit `src/main/resources/healing-config.properties`:

```properties
# Disable a specific layer
healing.layer2.enabled=false     # Skip Healenium (e.g., no Docker)
healing.layer4.enabled=false     # Skip LLM (e.g., no API key)

# Tune Layer 3 scoring weights
healing.score.weight.text=0.45   # Text most stable
healing.score.weight.attribute=0.25
healing.score.weight.class=0.20
healing.score.weight.position=0.10

# Layer 4 LLM settings
healing.layer4.llm.model=claude-sonnet-4-20250514
healing.layer4.llm.maxTokens=1000
```

---

## 📊 Expected Success Rates

| Layer | Strategy               | Speed    | Success Rate |
|-------|------------------------|----------|--------------|
| 1     | Cache & Quick Rules    | ~100ms   | 20-25%       |
| 2     | Healenium ML           | 2-5s     | 55-65%       |
| 3     | Advanced Fallback      | 1-4s     | 15-22%       |
| 4     | Claude AI LLM          | 3-15s    | 60-80%*      |
| **Overall** | **All Layers** | **varies** | **90%+**  |

*Layer 4 rate is of cases that reach it

---

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| `No API key` for Layer 4 | `export ANTHROPIC_API_KEY=sk-ant-...` |
| Layer 2 backend unavailable | `docker-compose up -d` & wait 60s |
| ChromeDriver mismatch | WebDriverManager auto-resolves it |
| Tests time out | Increase `healing.layer*.timeout.ms` |
| Low cache hit rate | Normal on first run; improves over runs |

---

## 📖 Key Classes Reference

| Class | Purpose |
|-------|---------|
| `SelfHealingWebDriver` | Drop-in WebDriver replacement |
| `HybridHealingCoordinator` | Orchestrates all 4 layers |
| `BaseTest` | Extend for your test classes |
| `DriverFactory` | Creates browser drivers |
| `HealingConfig` | All configuration settings |
| `HealingReporter` | Generates HTML dashboard |

---

**Last Updated:** April 2026 | **Maintained By:** Automation Team
