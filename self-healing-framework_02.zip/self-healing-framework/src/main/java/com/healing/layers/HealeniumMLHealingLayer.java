package com.healing.layers;

import com.epam.healenium.SelfHealingDriver;
import com.healing.config.HealingConfig;
import com.healing.core.IHealingLayer;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.HttpURLConnection;
import java.net.URL;

/**
 * =====================================================================
 * LAYER 2 - APPROACH 2: EPAM Healenium ML Engine
 * =====================================================================
 *
 * Leverages EPAM Healenium's backend ML service which uses:
 *   - Longest Common Subsequence (LCS) algorithm
 *   - Tree Edit Distance (DOM structural similarity)
 *   - Weighted attribute scoring
 *   - PostgreSQL persistence of healing history
 *
 * Pre-condition: Healenium Docker containers must be running.
 *   docker-compose up -d
 *
 * Speed: 2–5 seconds
 * Target success rate: 55-65%
 */
public class HealeniumMLHealingLayer implements IHealingLayer {

    private static final Logger log = LoggerFactory.getLogger(HealeniumMLHealingLayer.class);
    private final HealingConfig config = HealingConfig.getInstance();

    @Override
    public String getLayerName() { return "Layer 2 - Healenium ML Engine"; }

    @Override
    public boolean isEnabled() { return config.isLayer2Enabled(); }

    @Override
    public int getLayerPriority() { return 2; }

    @Override
    public WebElement attemptHealing(ElementContext ctx, WebDriver driver, HealingResult result) {
        long start = System.currentTimeMillis();
        log.info("▶ [Layer 2] Starting Healenium ML healing for: {}", ctx.toCompactString());

        HealingResult.LayerAttempt attempt = result.getLayer2Attempt();

        // Check backend availability
        if (!isHealeniumBackendAvailable()) {
            long elapsed = System.currentTimeMillis() - start;
            attempt.markFailed(elapsed,
                    "Healenium backend not available at " + getHealeniumUrl() +
                    " — ensure Docker is running: docker-compose up -d");
            log.warn("⚠️  [Layer 2] Healenium backend unavailable — skipping to Layer 3");
            return null;
        }

        try {
            // Wrap driver with SelfHealingDriver if not already
            SelfHealingDriver healingDriver = wrapDriver(driver);

            // Let Healenium attempt to find and heal the element
            WebElement healed = healingDriver.findElement(ctx.getOriginalLocator());

            long elapsed = System.currentTimeMillis() - start;

            if (healed != null) {
                // Healenium doesn't expose the new locator directly — 
                // we note that healing occurred and use original as reference
                attempt.markSuccess(ctx.getOriginalLocator(), 0.85, elapsed,
                        "Healenium LCS + DOM Similarity");
                result.markOverallSuccess(ctx.getOriginalLocator(),
                        HealingResult.HealingLayer.LAYER_2_HEALENIUM_ML,
                        0.85, "Healenium ML - LCS + TreeEdit + WeightedScore");
                log.info("✅ [Layer 2] HEALED via Healenium ML in {}ms", elapsed);
                return healed;
            }

        } catch (NoSuchElementException e) {
            // Healenium exhausted its alternatives too
            long elapsed = System.currentTimeMillis() - start;
            attempt.markFailed(elapsed, "Healenium could not find element: " + e.getMessage());
            log.info("❌ [Layer 2] Healenium ML FAILED in {}ms — escalating to Layer 3", elapsed);
        } catch (Exception e) {
            long elapsed = System.currentTimeMillis() - start;
            attempt.markFailed(elapsed, "Healenium error: " + e.getMessage());
            log.warn("❌ [Layer 2] Unexpected error in Healenium: {} — escalating to Layer 3",
                    e.getMessage());
        }

        return null;
    }

    /**
     * Wrap WebDriver with SelfHealingDriver if not already wrapped.
     */
    private SelfHealingDriver wrapDriver(WebDriver driver) {
        if (driver instanceof SelfHealingDriver) {
            return (SelfHealingDriver) driver;
        }
        return SelfHealingDriver.create(driver);
    }

    /**
     * Check if the Healenium backend Docker service is reachable.
     */
    private boolean isHealeniumBackendAvailable() {
        try {
            URL url = new URL(getHealeniumUrl() + "/healenium/health");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(2000);
            conn.setReadTimeout(2000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            conn.disconnect();
            boolean available = (code >= 200 && code < 400);
            if (available) log.debug("Healenium backend is UP at {}", getHealeniumUrl());
            return available;
        } catch (Exception e) {
            log.debug("Healenium backend health check failed: {}", e.getMessage());
            return false;
        }
    }

    private String getHealeniumUrl() {
        return String.format("http://%s:%d",
                config.getHealeniumHost(), config.getHealeniumPort());
    }
}
