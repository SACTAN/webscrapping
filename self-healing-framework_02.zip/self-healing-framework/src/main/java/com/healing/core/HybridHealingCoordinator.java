package com.healing.core;

import com.healing.config.HealingConfig;
import com.healing.layers.*;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import com.healing.reporting.HealingReporter;
import com.healing.utils.ContextExtractor;
import org.openqa.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * =====================================================================
 * HYBRID HEALING COORDINATOR - The Master Orchestrator
 * =====================================================================
 *
 * Controls the 4-layer sequential healing pipeline:
 *
 *   ┌────────────────────────────────────────────────────────┐
 *   │              ORIGINAL LOCATOR (FAILS)                  │
 *   └──────────────────────┬─────────────────────────────────┘
 *                          ▼
 *   ┌──────────────────────────────────────────────────────────┐
 *   │  LAYER 1: Cache & Quick Rules                  ~100ms   │
 *   │  - Cache lookup                                         │
 *   │  - Case variations, attribute swap                      │
 *   │  - Prefix/suffix manipulation                           │
 *   │  - Partial ID/CSS containment                           │
 *   └──────────────────────┬───────────────────────────────────┘
 *                          │ if FAIL ↓
 *   ┌──────────────────────────────────────────────────────────┐
 *   │  LAYER 2: Healenium ML Engine                  2-5s     │
 *   │  - LCS (Longest Common Subsequence)                     │
 *   │  - Tree Edit Distance (DOM similarity)                  │
 *   │  - Weighted attribute scoring                           │
 *   │  - PostgreSQL-backed learning history                   │
 *   └──────────────────────┬───────────────────────────────────┘
 *                          │ if FAIL ↓
 *   ┌──────────────────────────────────────────────────────────┐
 *   │  LAYER 3: Advanced Fallback Engine             1-4s     │
 *   │  - Text-based search                                    │
 *   │  - Fuzzy LCS attribute matching                        │
 *   │  - Data-attribute (data-testid, aria-label)             │
 *   │  - Structural hierarchy navigation                      │
 *   │  - XPath simplification                                 │
 *   │  - Sibling-based search                                 │
 *   └──────────────────────┬───────────────────────────────────┘
 *                          │ if FAIL ↓
 *   ┌──────────────────────────────────────────────────────────┐
 *   │  LAYER 4: Claude AI LLM                       3-15s     │
 *   │  - Sends full DOM context to Claude API                 │
 *   │  - Claude analyzes & suggests up to 5 locators          │
 *   │  - Each suggestion tried sequentially                   │
 *   └──────────────────────┬───────────────────────────────────┘
 *                          │
 *   ┌──────────────────────▼───────────────────────────────────┐
 *   │  RESULT: Healed Element OR Test Failure                  │
 *   └──────────────────────────────────────────────────────────┘
 */
public class HybridHealingCoordinator {

    private static final Logger log = LoggerFactory.getLogger(HybridHealingCoordinator.class);
    private final HealingConfig config = HealingConfig.getInstance();
    private final ContextExtractor contextExtractor = new ContextExtractor();
    private final HealingReporter reporter;

    // ---- The 4 healing layers (ordered) ----
    private final List<IHealingLayer> layers;

    public HybridHealingCoordinator() {
        this.layers = Arrays.asList(
            new CacheAndRulesHealingLayer(),   // Layer 1 - Approach 1
            new HealeniumMLHealingLayer(),     // Layer 2 - Approach 2
            new AdvancedFallbackHealingLayer(),// Layer 3 - Approach 3
            new LLMAIHealingLayer()            // Layer 4 - LLM AI
        );
        this.reporter = new HealingReporter();
    }

    /**
     * Main entry point: try to heal a failed element using all 4 layers.
     *
     * @param originalLocator The locator that failed
     * @param exception       The exception that was thrown
     * @param driver          Active WebDriver
     * @return Healed WebElement or throws the original exception
     */
    public WebElement heal(By originalLocator, Exception exception, WebDriver driver) {
        if (!config.isHealingEnabled()) {
            log.debug("Self-healing is disabled; re-throwing exception");
            rethrow(exception);
            return null;
        }

        long globalStart = System.currentTimeMillis();
        log.info("\n" +
                 "╔══════════════════════════════════════════════════════╗\n" +
                 "║        SELF-HEALING COORDINATOR ACTIVATED            ║\n" +
                 "║  Locator: {}                                         \n" +
                 "╚══════════════════════════════════════════════════════╝",
                 originalLocator);

        // Extract full context
        ElementContext ctx = contextExtractor.extract(originalLocator, driver,
                exception != null ? exception.getMessage() : "Unknown failure");

        HealingResult result = new HealingResult(originalLocator);

        // Run each layer sequentially; stop at first success
        for (IHealingLayer layer : layers) {
            if (!layer.isEnabled()) {
                log.info("⏭  [{}] is DISABLED — skipping", layer.getLayerName());
                continue;
            }

            log.info("──────────────────────────────────────────────────────");
            log.info("🔄 Attempting: {}", layer.getLayerName());

            try {
                WebElement healed = layer.attemptHealing(ctx, driver, result);

                if (healed != null) {
                    long totalMs = System.currentTimeMillis() - globalStart;
                    result.setHealingTimeMs(totalMs);
                    logSuccess(result, totalMs);
                    reporter.recordSuccess(result);
                    return healed;
                }

            } catch (Exception e) {
                log.error("Unexpected error in {}: {}", layer.getLayerName(), e.getMessage());
                // Continue to next layer
            }
        }

        // All layers failed
        long totalMs = System.currentTimeMillis() - globalStart;
        result.setHealingTimeMs(totalMs);
        result.markOverallFailed("All 4 healing layers exhausted after " + totalMs + "ms");

        log.error("\n" +
                  "╔══════════════════════════════════════════════════════╗\n" +
                  "║         ❌ ALL HEALING LAYERS FAILED                  ║\n" +
                  "║  Locator: {}                                          \n" +
                  "║  Total time: {}ms                                     \n" +
                  "╚══════════════════════════════════════════════════════╝",
                  originalLocator, totalMs);

        reporter.recordFailure(result);
        rethrow(exception);
        return null; // unreachable, but satisfies compiler
    }

    private void logSuccess(HealingResult result, long totalMs) {
        log.info("\n" +
                 "╔══════════════════════════════════════════════════════╗\n" +
                 "║         ✅ ELEMENT SUCCESSFULLY HEALED               ║\n" +
                 "║  Layer: {}                                            \n" +
                 "║  Strategy: {}                                         \n" +
                 "║  Confidence: {}                                       \n" +
                 "║  Total time: {}ms                                     \n" +
                 "╚══════════════════════════════════════════════════════╝",
                 result.getSuccessLayer() != null ? result.getSuccessLayer().getDisplayName() : "?",
                 result.getHealingStrategy(),
                 String.format("%.2f", result.getConfidenceScore()),
                 totalMs);
    }

    private void rethrow(Exception e) {
        if (e instanceof RuntimeException) throw (RuntimeException) e;
        if (e instanceof NoSuchElementException) throw (NoSuchElementException) e;
        throw new NoSuchElementException("Self-healing exhausted all strategies: " +
                (e != null ? e.getMessage() : "unknown"), e);
    }
}
