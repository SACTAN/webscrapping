package com.healing.utils;

import com.healing.core.SelfHealingWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

/**
 * Factory for creating self-healing WebDriver instances.
 *
 * Usage:
 *   SelfHealingWebDriver driver = DriverFactory.createChromeDriver();
 *   SelfHealingWebDriver driver = DriverFactory.createChromeDriver(true); // headless
 */
public class DriverFactory {

    private static final Logger log = LoggerFactory.getLogger(DriverFactory.class);

    public enum BrowserType { CHROME, FIREFOX, EDGE }

    /**
     * Create a Chrome SelfHealingWebDriver.
     */
    public static SelfHealingWebDriver createChromeDriver() {
        return createChromeDriver(false);
    }

    public static SelfHealingWebDriver createChromeDriver(boolean headless) {
        log.info("Creating Chrome SelfHealingWebDriver (headless={})", headless);
        WebDriverManager.chromedriver().setup();

        ChromeOptions opts = new ChromeOptions();
        if (headless) {
            opts.addArguments("--headless=new");
        }
        opts.addArguments(
            "--disable-blink-features=AutomationControlled",
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--window-size=1920,1080",
            "--remote-allow-origins=*"
        );
        opts.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

        WebDriver raw = new ChromeDriver(opts);
        raw.manage().timeouts().implicitlyWait(Duration.ofSeconds(0)); // Healing manages waits
        raw.manage().window().maximize();

        SelfHealingWebDriver driver = SelfHealingWebDriver.wrap(raw);
        log.info("Chrome SelfHealingWebDriver ready");
        return driver;
    }

    /**
     * Create a Firefox SelfHealingWebDriver.
     */
    public static SelfHealingWebDriver createFirefoxDriver() {
        return createFirefoxDriver(false);
    }

    public static SelfHealingWebDriver createFirefoxDriver(boolean headless) {
        log.info("Creating Firefox SelfHealingWebDriver (headless={})", headless);
        WebDriverManager.firefoxdriver().setup();

        FirefoxOptions opts = new FirefoxOptions();
        if (headless) opts.addArguments("-headless");

        WebDriver raw = new FirefoxDriver(opts);
        raw.manage().window().maximize();
        return SelfHealingWebDriver.wrap(raw);
    }

    /**
     * Create an Edge SelfHealingWebDriver.
     */
    public static SelfHealingWebDriver createEdgeDriver() {
        log.info("Creating Edge SelfHealingWebDriver");
        WebDriverManager.edgedriver().setup();

        EdgeOptions opts = new EdgeOptions();
        opts.addArguments("--window-size=1920,1080");

        WebDriver raw = new EdgeDriver(opts);
        raw.manage().window().maximize();
        return SelfHealingWebDriver.wrap(raw);
    }

    /**
     * Generic factory method.
     */
    public static SelfHealingWebDriver create(BrowserType browser, boolean headless) {
        switch (browser) {
            case FIREFOX: return createFirefoxDriver(headless);
            case EDGE:    return createEdgeDriver();
            case CHROME:
            default:      return createChromeDriver(headless);
        }
    }
}
