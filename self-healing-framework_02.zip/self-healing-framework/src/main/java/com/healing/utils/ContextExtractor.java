package com.healing.utils;

import com.healing.models.ElementContext;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;

/**
 * Extracts rich context from a failed element to give healing layers
 * as much information as possible.
 */
public class ContextExtractor {

    private static final Logger log = LoggerFactory.getLogger(ContextExtractor.class);

    /**
     * Build a full ElementContext for a failed locator.
     */
    public ElementContext extract(By originalLocator, WebDriver driver, String exceptionMessage) {
        ElementContext ctx = new ElementContext(originalLocator);
        ctx.withExceptionMessage(exceptionMessage);

        try {
            // Page-level info
            ctx.withPageUrl(safeGet(() -> driver.getCurrentUrl()));
            ctx.withPageTitle(safeGet(() -> driver.getTitle()));

            // Truncate page source to first 20KB (enough for LLM context)
            String fullSource = safeGet(() -> driver.getPageSource());
            if (fullSource != null && fullSource.length() > 20000) {
                fullSource = fullSource.substring(0, 20000);
            }
            ctx.withPageSource(fullSource);

            // Try to get partial element info even if it's stale
            tryExtractElementInfo(originalLocator, driver, ctx);

            // Screenshot for LLM (base64)
            String screenshot = safeGet(() -> {
                TakesScreenshot ts = (TakesScreenshot) driver;
                byte[] bytes = ts.getScreenshotAs(OutputType.BYTES);
                return Base64.getEncoder().encodeToString(bytes);
            });
            ctx.withScreenshotBase64(screenshot);

        } catch (Exception e) {
            log.warn("Error extracting context: {}", e.getMessage());
        }

        return ctx;
    }

    private void tryExtractElementInfo(By locator, WebDriver driver, ElementContext ctx) {
        try {
            // Element might be present but stale — quick check
            WebElement el = driver.findElement(locator);
            ctx.withTagName(safeGet(el::getTagName));
            ctx.withInnerText(safeGet(el::getText));

            Map<String, String> attrs = new LinkedHashMap<>();
            for (String attr : Arrays.asList("id", "name", "class", "type", "value",
                    "data-testid", "aria-label", "placeholder", "href")) {
                String val = safeGet(() -> el.getAttribute(attr));
                if (val != null && !val.isEmpty()) attrs.put(attr, val);
            }
            ctx.withAttributes(attrs);

            // Try to get parent XPath via JS
            String parentXPath = (String) ((JavascriptExecutor) driver).executeScript(
                    "var el = arguments[0]; var path = ''; " +
                    "while (el && el.nodeType == 1) { " +
                    "  var name = el.nodeName.toLowerCase(); " +
                    "  path = '/' + name + path; " +
                    "  el = el.parentNode; " +
                    "} return path;", el);
            ctx.withParentXPath(parentXPath);

        } catch (NoSuchElementException | StaleElementReferenceException e) {
            log.debug("Element not directly accessible; context extraction proceeds with page source only");
        } catch (Exception e) {
            log.debug("Partial element extraction error: {}", e.getMessage());
        }
    }

    private <T> T safeGet(java.util.function.Supplier<T> supplier) {
        try { return supplier.get(); }
        catch (Exception e) { return null; }
    }
}
