package com.healing.utils;

/**
 * Longest Common Subsequence (LCS) based string similarity calculator.
 *
 * Used by Layer 3 (Advanced Fallback) to score candidate elements
 * against the original failed locator attributes.
 *
 * Algorithm: O(m × n) dynamic programming
 * Score range: 0.0 (no match) to 1.0 (exact match)
 */
public class LCSAlgorithm {

    /**
     * Compute similarity between two strings using LCS ratio.
     *
     * @return score in [0.0, 1.0]
     */
    public double similarity(String str1, String str2) {
        if (str1 == null && str2 == null) return 1.0;
        if (str1 == null || str2 == null) return 0.0;
        str1 = str1.trim().toLowerCase();
        str2 = str2.trim().toLowerCase();
        if (str1.equals(str2)) return 1.0;
        if (str1.isEmpty() && str2.isEmpty()) return 1.0;
        if (str1.isEmpty() || str2.isEmpty()) return 0.0;

        int lcsLen = computeLCSLength(str1, str2);
        int maxLen = Math.max(str1.length(), str2.length());
        return (double) lcsLen / maxLen;
    }

    /**
     * Compute weighted similarity score for a candidate element
     * against a reference locator value.
     *
     * Weights per the AI/ML document:
     *   text: 0.45  (most stable)
     *   id:   0.25
     *   class: 0.20
     *   position: 0.10
     */
    public double computeWeightedScore(String refId, String refText, String refClass,
                                       String candId, String candText, String candClass,
                                       double weightId, double weightText, double weightClass) {
        double idScore    = similarity(refId, candId);
        double textScore  = similarity(refText, candText);
        double classScore = similarity(refClass, candClass);

        return (idScore * weightId) + (textScore * weightText) + (classScore * weightClass);
    }

    /**
     * Jaccard similarity for sets of tokens (for class comparison).
     */
    public double jaccardSimilarity(String tokens1, String tokens2) {
        if (tokens1 == null || tokens2 == null) return 0.0;
        String[] set1 = tokens1.toLowerCase().split("\\s+");
        String[] set2 = tokens2.toLowerCase().split("\\s+");

        java.util.Set<String> union = new java.util.HashSet<>();
        java.util.Set<String> intersection = new java.util.HashSet<>();

        java.util.Collections.addAll(union, set1);
        java.util.Collections.addAll(union, set2);

        java.util.Set<String> s1set = new java.util.HashSet<>(java.util.Arrays.asList(set1));
        for (String s : set2) {
            if (s1set.contains(s)) intersection.add(s);
        }
        return union.isEmpty() ? 0.0 : (double) intersection.size() / union.size();
    }

    /**
     * Contains-based partial match (useful for partial id/class changes).
     */
    public boolean partialMatch(String original, String candidate, double threshold) {
        if (original == null || candidate == null) return false;
        double sim = similarity(original, candidate);
        return sim >= threshold;
    }

    // ---- Core LCS DP ----
    private int computeLCSLength(String s1, String s2) {
        int m = s1.length();
        int n = s2.length();

        // Space optimization: use two rows
        int[] prev = new int[n + 1];
        int[] curr = new int[n + 1];

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    curr[j] = prev[j - 1] + 1;
                } else {
                    curr[j] = Math.max(prev[j], curr[j - 1]);
                }
            }
            int[] tmp = prev; prev = curr; curr = tmp;
            java.util.Arrays.fill(curr, 0);
        }
        return prev[n];
    }
}
