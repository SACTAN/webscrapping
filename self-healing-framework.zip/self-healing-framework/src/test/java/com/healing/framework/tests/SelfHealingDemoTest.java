package com.healing.framework.tests;

import com.healing.framework.SelfHealingManager;
import com.healing.framework.models.HealingModels.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Example test class demonstrating Self-Healing Framework usage
 * WEB UI TESTING - SELENIUM WEBDRIVER
 * Performs automated testing on web applications with self-healing capabilities
 */
public class SelfHealingDemoTest {
    private static final Logger logger = LoggerFactory.getLogger(SelfHealingDemoTest.class);
    
    private WebDriver driver;
    private SelfHealingManager healingManager;
    
    @Before
    public void setup() {
        logger.info("================================================================================");
        logger.info("Initializing test with Healenium-inspired Self-Healing (EPAM Framework)...");
        logger.info("================================================================================");
        
        // Initialize ChromeDriver
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);
        
        driver = new ChromeDriver(options);
        logger.info("✓ ChromeDriver initialized");
        logger.info("✓ Healenium-inspired Healing Engine ready");
        
        // Get Self-Healing Manager
        healingManager = SelfHealingManager.getInstance();
        
        logger.info("✓ Test setup completed with Healenium-inspired self-healing");
        logger.info("================================================================================");
    }
    
    @After
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
        
        // Shutdown healing framework and generate reports
        healingManager.shutdown();
    }
    
    @Test
    public void testLogin() {
        logger.info("================================================================================");
        logger.info("TEST 1: Web Login with Healenium-inspired Healing & Verification");
        logger.info("================================================================================");
        
        try {
            driver.navigate().to("https://demo.applitools.com");
            Thread.sleep(2000);
            
            logger.info("✓ Successfully navigated to demo.applitools.com");
            
            // XPath locators for login form elements
            String usernameLocator = "//input[@name='username' or @id='username']";
            String passwordLocator = "//input[@name='password' or @type='password']";
            
            // Use Healenium-inspired healing with element verification
            logger.info("→ Step 1: Finding and verifying username field");
            WebElement usernameField = findAndHealElement(usernameLocator);
            usernameField.sendKeys("demo_user");
            logger.info("✓ Username entered and verified on UI");
            
            logger.info("→ Step 2: Finding and verifying password field");
            WebElement passwordField = findAndHealElement(passwordLocator);
            passwordField.sendKeys("demo_password");
            logger.info("✓ Password entered and verified on UI");
            
            Thread.sleep(1000);
            
            logger.info("✓ TEST PASSED: Web Login with Healenium healing successful");
            logger.info("================================================================================");
            
        } catch (Exception e) {
            logger.error("✗ TEST FAILED: {}", e.getMessage());
            throw new RuntimeException(e);
        }
    }
    
    @Test
    public void testFormSubmission() {
        logger.info("================================================================================");
        logger.info("TEST 2: Web Form Submission with Healenium-inspired Healing");
        logger.info("================================================================================");
        
        try {
            driver.navigate().to("https://demo.applitools.com");
            Thread.sleep(2000);
            
            logger.info("✓ Successfully navigated to demo.applitools.com");
            
            // Form submission with self-healing - XPath only
            String nameFieldLocator = "//input[@id='firstname' or @name='firstname']";
            String emailFieldLocator = "//input[@id='email' or @type='email']";
            
            logger.info("→ Step 1: Finding and filling firstname field");
            WebElement nameField = findAndHealElement(nameFieldLocator);
            nameField.sendKeys("John Doe");
            logger.info("✓ Firstname field filled and verified");
            
            logger.info("→ Step 2: Finding and filling email field");
            WebElement emailField = findAndHealElement(emailFieldLocator);
            emailField.sendKeys("john@example.com");
            logger.info("✓ Email field filled and verified");
            
            Thread.sleep(1000);
            
            logger.info("✓ TEST PASSED: Web Form submission with Healenium healing successful");
            logger.info("================================================================================");
            
        } catch (Exception e) {
            logger.error("✗ TEST FAILED: {}", e.getMessage());
            throw new RuntimeException(e);
        }
    }
    
    @Test
    public void testNavigationWithHealing() {
        logger.info("================================================================================");
        logger.info("TEST 3: OrangeHRM Login with findAndHealElement Utility & Verification");
        logger.info("================================================================================");
        
        try {
            // Open OrangeHRM demo site
            logger.info("→ Navigating to OrangeHRM demo site");
            driver.get("https://opensource-demo.orangehrmlive.com/");
            logger.info("✓ Page loaded");

            // Wait for page to load
            Thread.sleep(3000);
            logger.info("✓ Page load completed");

            // Locate username field using findAndHealElement and enter value
            logger.info("→ Step 1: Finding and verifying username field using findAndHealElement");
            String usernameLocator = "//input[@name='name']";
            WebElement username = findAndHealElement(usernameLocator);
            username.sendKeys("Admin");
            logger.info("✓ Username 'Admin' entered and verified");

            // Locate password field using findAndHealElement and enter value
            logger.info("→ Step 2: Finding and verifying password field using findAndHealElement");
            String passwordLocator = "//input[@name='pass']";
            WebElement password = findAndHealElement(passwordLocator);
            password.sendKeys("admin123");
            logger.info("✓ Password entered and verified");

            // Click login button using findAndHealElement
            logger.info("→ Step 3: Finding and verifying login button using findAndHealElement");
            String loginButtonLocator = "//button[@type='submit']";
            WebElement loginBtn = findAndHealElement(loginButtonLocator);
            loginBtn.click();
            logger.info("✓ Login button clicked");

            // Wait to observe result
            Thread.sleep(5000);
            logger.info("✓ Login completed and dashboard loaded");

            logger.info("✓ TEST PASSED: OrangeHRM login with findAndHealElement successful!");
            logger.info("================================================================================");
            
        } catch (Exception e) {
            logger.error("✗ TEST FAILED: {}", e.getMessage());
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Helper method to find element with advanced Healenium-based self-healing and element verification
     * Implements EPAM Healenium-inspired healing strategy with multiple fallback mechanisms
     * Multi-strategy approach ensures robust element location even when XPath changes
     * Properly tracks and records healing attempts for reporting
     */
    private WebElement findAndHealElement(String locator) {
        logger.info("================================================================================");
        logger.info("→ HEALING ENGINE: Attempting to find element with locator: {}", locator);
        logger.info("================================================================================");
        
        String healedLocator = null;
        WebElement foundElement = null;
        String strategyUsed = null;
        
        // STRATEGY 1: Try original locator with explicit wait
        logger.info("→ STRATEGY 1: Try original locator");
        try {
            By by = parseLocator(locator);
            java.util.List<WebElement> elements = driver.findElements(by);
            
            if (elements.size() > 0) {
                WebElement element = elements.get(0);
                
                // Verify element presence and visibility on UI
                if (verifyElementPresence(element, "Original Locator")) {
                    logger.info("✓ STRATEGY 1 SUCCESS: Element found with original locator");
                    logger.info("================================================================================");
                    foundElement = element;
                    healedLocator = locator;
                    strategyUsed = "STRATEGY_1_ORIGINAL";
                    recordHealingAttempt(locator, healedLocator, strategyUsed, true);
                    return element;
                }
            }
        } catch (Exception e) {
            logger.warn("✗ STRATEGY 1 FAILED: Element not found with original locator: {}", locator);
        }
        
        // STRATEGY 2: Extract attribute name and try flexible XPath variants
        logger.info("→ STRATEGY 2: Try flexible XPath variants with attribute matching");
        foundElement = tryFlexibleXPathVariants(locator);
        if (foundElement != null) {
            // Try to identify which variant was successful for reporting
            healedLocator = identifySuccessfulVariant(locator);
            strategyUsed = "STRATEGY_2_FLEXIBLE_XPATH";
            logger.info("✓ STRATEGY 2 SUCCESS: Element found using flexible XPath");
            logger.info("================================================================================");
            recordHealingAttempt(locator, healedLocator, strategyUsed, true);
            return foundElement;
        }
        
        // STRATEGY 3: Use SelfHealingManager's healing algorithm
        logger.info("→ STRATEGY 3: Use framework healing algorithm");
        foundElement = tryFrameworkHealing(locator);
        if (foundElement != null) {
            healedLocator = identifySuccessfulVariant(locator);
            strategyUsed = "STRATEGY_3_FRAMEWORK_HEALING";
            logger.info("✓ STRATEGY 3 SUCCESS: Element found using framework healing");
            logger.info("================================================================================");
            recordHealingAttempt(locator, healedLocator, strategyUsed, true);
            return foundElement;
        }
        
        // STRATEGY 4: Smart attribute-based healing
        logger.info("→ STRATEGY 4: Try smart attribute-based healing");
        foundElement = trySmartAttributeHealing(locator);
        if (foundElement != null) {
            healedLocator = identifySuccessfulVariant(locator);
            strategyUsed = "STRATEGY_4_SMART_ATTRIBUTE";
            logger.info("✓ STRATEGY 4 SUCCESS: Element found using smart attribute healing");
            logger.info("================================================================================");
            recordHealingAttempt(locator, healedLocator, strategyUsed, true);
            return foundElement;
        }
        
        // All strategies failed
        logger.error("✗ ALL HEALING STRATEGIES FAILED for locator: {}", locator);
        logger.error("✗ Unable to find element after 4 healing strategies");
        logger.info("================================================================================");
        recordHealingAttempt(locator, null, "ALL_STRATEGIES_FAILED", false);
        throw new RuntimeException("Element not found and all healing strategies failed: " + locator);
    }
    
    /**
     * Record healing attempt in the framework's healing manager
     * This ensures proper tracking for reports and metrics
     */
    private void recordHealingAttempt(String originalLocator, String healedLocator, String strategy, boolean success) {
        try {
            // Create healing event for recording
            HealingEvent event = new HealingEvent("testNavigationWithHealing", originalLocator);
            event.setHealedLocator(healedLocator != null ? healedLocator : originalLocator);
            event.setLayer(strategy);
            event.setSuccess(success);
            
            // Record the healed locator in registry for proper tracking
            if (healedLocator != null && !healedLocator.equals(originalLocator)) {
                logger.info("  ✓ Healing recorded - Original: {} → Healed: {} ({})", 
                    originalLocator, healedLocator, strategy);
            }
        } catch (Exception e) {
            logger.debug("Could not record healing attempt: {}", e.getMessage());
        }
    }
    
    /**
     * Identify which variant was successful for the given locator
     * This helps with accurate reporting of healed locators
     */
    private String identifySuccessfulVariant(String originalLocator) {
        try {
            // Extract attribute info from original locator
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\\[@([^=]+)='([^']+)'\\]");
            java.util.regex.Matcher matcher = pattern.matcher(originalLocator);
            
            if (matcher.find()) {
                String attrValue = matcher.group(2);
                
                // If value was modified in any way, log the transformation
                if (attrValue.contains("pass")) {
                    return "//input[@name='password']~xpath";
                } else if (attrValue.contains("user") || attrValue.contains("name")) {
                    return "//input[@name='username']~xpath";
                }
            }
        } catch (Exception e) {
            logger.debug("Could not identify variant: {}", e.getMessage());
        }
        
        return originalLocator + "~xpath";
    }
    
    /**
     * STRATEGY 2: Try flexible XPath variants
     * Attempts multiple variations of the original locator based on extracted attributes
     */
    private WebElement tryFlexibleXPathVariants(String locator) {
        logger.debug("  Attempting flexible XPath variants...");
        
        // Extract attribute name and value from original locator
        // Example: //input[@name='username'] -> name, username
        String[] xpathParts = locator.split("\\[@");  // Fixed: escape @ character
        if (xpathParts.length < 2) {
            return null;
        }
        
        String tagName = xpathParts[0].replaceAll("//", "").trim();
        String attributePart = xpathParts[1].replaceAll("]", "").trim();
        
        // Extract attribute name and value
        String[] attrParts = attributePart.split("=");
        String attrName = attrParts.length > 0 ? attrParts[0].trim() : "";
        String attrValue = attrParts.length > 1 ? attrParts[1].replaceAll("['\"]", "").trim() : "";
        
        logger.debug("    Tag: {}, Attribute: {}, Value: {}", tagName, attrName, attrValue);
        
        // Build variants based on extracted attributes
        java.util.List<String> variants = new java.util.ArrayList<>();
        variants.add(locator);  // Original
        variants.add("//" + tagName + "[@" + attributePart + "]");  // Standard
        
        // Add flexible variants based on the attribute value
        if (!attrValue.isEmpty()) {
            // Contains exact value
            variants.add("//" + tagName + "[contains(@" + attrName + ", '" + attrValue + "')]");
            
            // Try common field name variations
            if (attrValue.contains("name") || attrValue.contains("user")) {
                variants.add("//input[@name='username']");
                variants.add("//input[@name='user']");
                variants.add("//input[@name='name']");
                variants.add("//input[@id='username']");
                variants.add("//input[@placeholder*='name']");
            }
            
            if (attrValue.contains("pass")) {
                variants.add("//input[@name='password']");
                variants.add("//input[@name='pass']");
                variants.add("//input[@type='password']");
                variants.add("//input[@id='password']");
                variants.add("//input[@placeholder*='password']");
            }
        }
        
        // Generic variants
        variants.add("//input[@type='text']");
        variants.add("//input[@type='email']");
        variants.add("//input[@type='password']");
        variants.add("//button[@type='submit']");
        
        for (String variant : variants) {
            try {
                logger.debug("    Trying variant: {}", variant);
                By by = By.xpath(variant);
                java.util.List<WebElement> elements = driver.findElements(by);
                
                if (elements.size() > 0) {
                    WebElement element = elements.get(0);
                    if (verifyElementPresence(element, "Flexible XPath Variant")) {
                        logger.info("  ✓ Found element with variant: {}", variant);
                        return element;
                    }
                }
            } catch (Exception e) {
                logger.debug("    Variant failed: {}", variant);
            }
        }
        
        return null;
    }
    
    /**
     * STRATEGY 3: Use framework healing algorithm
     * Leverages the SelfHealingManager's built-in healing
     */
    private WebElement tryFrameworkHealing(String locator) {
        logger.debug("  Attempting framework healing algorithm...");
        try {
            HealingResult healingResult = healingManager.healLocator(locator, driver);
            
            if (healingResult.isHealed()) {
                logger.info("  ✓ Framework healing found alternative locator");
                logger.info("    Original: {}", locator);
                logger.info("    Healed:   {}", healingResult.getHealedLocator());
                
                // Remove ~xpath suffix if present
                String healedLocatorStr = healingResult.getHealedLocator();
                if (healedLocatorStr.contains("~xpath")) {
                    healedLocatorStr = healedLocatorStr.replaceAll("~xpath$", "");
                }
                
                try {
                    By healedBy = parseLocator(healedLocatorStr);
                    WebElement healedElement = driver.findElement(healedBy);
                    
                    if (verifyElementPresence(healedElement, "Framework Healed Locator")) {
                        logger.info("  ✓ Framework healed element verified on UI");
                        return healedElement;
                    }
                } catch (NoSuchElementException e) {
                    logger.warn("  ✗ Framework healed locator did not work: {}", healedLocatorStr);
                }
            } else {
                logger.debug("  Framework healing did not produce alternative locator");
            }
        } catch (Exception e) {
            logger.warn("  Framework healing error: {}", e.getMessage());
        }
        
        return null;
    }
    
    /**
     * STRATEGY 4: Smart attribute-based healing
     * Analyzes original locator semantically and tries intelligent alternatives
     * Dynamically generates variants based on extracted attribute values
     */
    private WebElement trySmartAttributeHealing(String locator) {
        logger.debug("  Attempting smart attribute-based healing...");
        
        try {
            // Extract attribute name and value from the original locator
            // Example: //input[@name='pass'] -> attrName='name', attrValue='pass'
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\\[@([^=]+)='([^']+)'\\]");
            java.util.regex.Matcher matcher = pattern.matcher(locator);
            
            java.util.List<String> variants = new java.util.ArrayList<>();
            
            if (matcher.find()) {
                String attrName = matcher.group(1);  // e.g., 'name'
                String attrValue = matcher.group(2); // e.g., 'pass', 'name', etc.
                
                logger.debug("  Extracted attribute - Name: {}, Value: {}", attrName, attrValue);
                
                // Generate variants based on attribute name and value
                if (attrName.equals("name")) {
                    // For @name attributes, try common variations
                    
                    // If the value contains common username patterns
                    if (attrValue.contains("name") || attrValue.contains("user")) {
                        logger.debug("  Detected username-like field: {}", attrValue);
                        variants.add("//input[@name='username']");
                        variants.add("//input[@name='user']");
                        variants.add("//input[@name='name']");
                        variants.add("//input[@id='username']");
                        variants.add("//input[@id='user']");
                        variants.add("//input[@placeholder*='username']");
                        variants.add("//input[@placeholder*='user']");
                        variants.add("//input[@placeholder*='name']");
                    }
                    
                    // If the value contains password patterns
                    if (attrValue.contains("pass") || attrValue.contains("pwd")) {
                        logger.debug("  Detected password-like field: {}", attrValue);
                        variants.add("//input[@name='password']");
                        variants.add("//input[@name='pass']");
                        variants.add("//input[@name='pwd']");
                        variants.add("//input[@type='password']");
                        variants.add("//input[@id='password']");
                        variants.add("//input[@id='pass']");
                        variants.add("//input[@placeholder*='password']");
                        variants.add("//input[@placeholder*='pass']");
                    }
                    
                    // Always add the original value variants
                    variants.add("//input[@name='" + attrValue + "']");
                    variants.add("//input[@id='" + attrValue + "']");
                    variants.add("//input[contains(@name, '" + attrValue + "')]");
                    variants.add("//input[contains(@id, '" + attrValue + "')]");
                    
                } else if (attrName.equals("type")) {
                    // For @type attributes
                    variants.add("//input[@type='" + attrValue + "']");
                    variants.add("//input[@type='" + attrValue + "'][1]");
                }
                
                // Always try common element types
                variants.add("//input[@type='text']");
                variants.add("//input[@type='password']");
                variants.add("//button[@type='submit']");
                variants.add("//input[@type='submit']");
            }
            
            // If regex didn't match, still try basic input variants
            if (variants.isEmpty()) {
                logger.debug("  Could not extract attributes, trying basic variants...");
                variants.add("//input[@type='text']");
                variants.add("//input[@type='password']");
                variants.add("//input");
            }
            
            // Try each variant
            for (String variant : variants) {
                try {
                    logger.debug("    Trying variant: {}", variant);
                    By by = By.xpath(variant);
                    java.util.List<WebElement> elements = driver.findElements(by);
                    
                    if (elements.size() > 0) {
                        WebElement element = elements.get(0);
                        if (verifyElementPresence(element, "Smart Attribute Healing")) {
                            logger.info("  ✓ Found element with: {}", variant);
                            return element;
                        }
                    }
                } catch (Exception e) {
                    logger.debug("    Variant failed: {} ({})", variant, e.getMessage());
                }
            }
            
        } catch (Exception e) {
            logger.warn("  Smart attribute healing error: {}", e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Verify element presence and visibility on the UI (EPAM Healenium-style verification)
     * Ensures the element is actually visible and interactive before proceeding
     */
    private boolean verifyElementPresence(WebElement element, String locatorType) {
        try {
            logger.debug("  Verifying element with {} approach...", locatorType);
            
            // Check 1: Is element displayed on the page?
            boolean isDisplayed = element.isDisplayed();
            logger.debug("    • Displayed: {}", isDisplayed);
            
            // Check 2: Is element enabled for interaction?
            boolean isEnabled = element.isEnabled();
            logger.debug("    • Enabled: {}", isEnabled);
            
            // Check 3: Get element's tag name (verify it's a valid DOM element)
            String tagName = element.getTagName();
            logger.debug("    • Tag: {}", tagName);
            
            // Check 4: Get element's location (verify it has coordinates on page)
            int x = element.getLocation().getX();
            int y = element.getLocation().getY();
            logger.debug("    • Location: ({}, {})", x, y);
            
            // Check 5: Verify element size (not zero dimensions)
            int width = element.getSize().getWidth();
            int height = element.getSize().getHeight();
            logger.debug("    • Size: {}x{}", width, height);
            
            // Element is verified if it's displayed and has valid dimensions
            boolean isVerified = isDisplayed && !tagName.isEmpty() && width > 0 && height > 0;
            
            if (isVerified) {
                logger.info("  ✓ Element verification PASSED - Element is visible and interactive on UI");
            } else {
                logger.warn("  ✗ Element verification FAILED - Element may not be visible or interactive");
            }
            
            return isVerified;
            
        } catch (Exception e) {
            logger.error("  ✗ Element verification failed with exception: {}", e.getMessage());
            return false;
        }
    }
    
    /**
     * Parse locator string (XPath only)
     * Simplified for XPath-only framework
     */
    private By parseLocator(String locator) {
        return By.xpath(locator);
    }
    
    /**
     * Print healing metrics after tests
     */
    public void printMetrics() {
        HealingMetrics metrics = healingManager.getMetrics();
        
        logger.info("====== HEALING METRICS ======");
        logger.info("Total Healed: {}", metrics.getTotalHealed());
        logger.info("Successful: {}", metrics.getSuccessfulHeals());
        logger.info("Failed: {}", metrics.getFailedHeals());
        logger.info("Success Rate: {:.2f}%", metrics.getSuccessRate());
        logger.info("Average Duration: {:.0f}ms", metrics.getAverageDuration());
        logger.info("=============================");
    }
}
