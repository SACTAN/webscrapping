package com.healing.framework.layers;

import com.healing.framework.config.HealingConfig;
import com.healing.framework.models.HealingModels.*;
import com.healing.framework.utils.LocatorUtils;
import com.healing.framework.utils.SimilarityAlgorithms;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Layer 1: Custom Pre-Processor
 * Fast, rule-based healing strategies for quick wins
 * Expected success rate: 18-25%
 * Execution time: 50-150ms
 */
public class PreProcessorLayer {
    private static final Logger logger = LoggerFactory.getLogger(PreProcessorLayer.class);
    private final HealingConfig config;
    private final Map<String, String> healingCache;
    private final int maxCacheSize;
    
    public PreProcessorLayer() {
        this.config = HealingConfig.getInstance();
        this.maxCacheSize = config.getPreprocessorMaxCacheSize();
        this.healingCache = new LinkedHashMap<String, String>(maxCacheSize, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
                return size() > maxCacheSize;
            }
        };
    }
    
    /**
     * Execute Layer 1 healing strategies
     */
    public HealingResult heal(String originalLocator, String pageSource) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.debug("Layer 1: Starting pre-processor healing for: {}", originalLocator);
            
            // Strategy 1: Cache Lookup
            HealingResult cached = cacheLayup(originalLocator);
            if (cached != null && cached.isHealed()) {
                cached.setDuration(System.currentTimeMillis() - startTime);
                logger.info("Layer 1: Cache hit for locator: {}", originalLocator);
                return cached;
            }
            
            // Strategy 2: XPath Simplification
            HealingResult simplified = xpathSimplification(originalLocator);
            if (simplified.isHealed()) {
                cacheHealing(originalLocator, simplified.getHealedLocator());
                simplified.setDuration(System.currentTimeMillis() - startTime);
                logger.info("Layer 1: XPath simplification successful: {} -> {}", 
                    originalLocator, simplified.getHealedLocator());
                return simplified;
            }
            
            // Strategy 3: Case Variation
            HealingResult caseVar = caseVariationHealing(originalLocator);
            if (caseVar.isHealed()) {
                cacheHealing(originalLocator, caseVar.getHealedLocator());
                caseVar.setDuration(System.currentTimeMillis() - startTime);
                logger.info("Layer 1: Case variation successful: {} -> {}", 
                    originalLocator, caseVar.getHealedLocator());
                return caseVar;
            }
            
            // Strategy 4: Attribute Swap
            HealingResult attrSwap = attributeSwapHealing(originalLocator);
            if (attrSwap.isHealed()) {
                cacheHealing(originalLocator, attrSwap.getHealedLocator());
                attrSwap.setDuration(System.currentTimeMillis() - startTime);
                logger.info("Layer 1: Attribute swap successful: {} -> {}", 
                    originalLocator, attrSwap.getHealedLocator());
                return attrSwap;
            }
            
            // No healing found
            HealingResult noHeal = new HealingResult(false, null, "Layer1-PreProcessor", 0, 
                System.currentTimeMillis() - startTime);
            noHeal.setMessage("No pre-processor strategy succeeded");
            logger.debug("Layer 1: No healing strategy succeeded for: {}", originalLocator);
            return noHeal;
            
        } catch (Exception e) {
            logger.error("Layer 1: Error during healing", e);
            return new HealingResult(false, null, "Layer1-PreProcessor", 0, 
                System.currentTimeMillis() - startTime);
        }
    }
    
    /**
     * Strategy 1: Cache Lookup
     */
    private HealingResult cacheLayup(String locator) {
        if (healingCache.containsKey(locator)) {
            String healed = healingCache.get(locator);
            return new HealingResult(true, healed, "Layer1-Cache", 0.95, 0);
        }
        return new HealingResult(false, null, "Layer1-Cache", 0, 0);
    }
    
    /**
     * Strategy 2: XPath Simplification
     * Remove complex predicates and try simpler versions
     */
    private HealingResult xpathSimplification(String locator) {
        String value = LocatorUtils.LocatorParser.getValue(locator);
        String type = LocatorUtils.LocatorParser.getType(locator);
        
        if (!type.equals(LocatorUtils.LocatorType.XPATH.getValue())) {
            return new HealingResult(false, null, "Layer1-XPathSimplify", 0, 0);
        }
        
        List<String> simplifications = LocatorUtils.XPathSimplifier.generateSimplifications(value);
        
        // Try progressively simpler XPaths (score increases with simpler paths)
        for (int i = 1; i < simplifications.size(); i++) {
            String simplified = simplifications.get(i);
            double score = 0.8 - (i * 0.1); // Decreasing confidence
            if (score > 0.5) {
                String healedLocator = LocatorUtils.formatLocator(simplified, type);
                return new HealingResult(true, healedLocator, "Layer1-XPathSimplify", score, 0);
            }
        }
        
        return new HealingResult(false, null, "Layer1-XPathSimplify", 0, 0);
    }
    
    /**
     * Strategy 3: Case Variation Healing
     * Try different case variations: lower, upper, capitalized
     */
    private HealingResult caseVariationHealing(String locator) {
        String value = LocatorUtils.LocatorParser.getValue(locator);
        String type = LocatorUtils.LocatorParser.getType(locator);
        
        List<String> variations = LocatorUtils.CaseVariations.generate(value);
        
        for (int i = 1; i < variations.size(); i++) {
            String variation = variations.get(i);
            if (!variation.equals(value)) {
                String healedLocator = LocatorUtils.formatLocator(variation, type);
                return new HealingResult(true, healedLocator, "Layer1-CaseVar", 0.75, 0);
            }
        }
        
        return new HealingResult(false, null, "Layer1-CaseVar", 0, 0);
    }
    
    /**
     * Strategy 4: Attribute Swap
     * Try alternative attribute names (id -> name -> accessibility-id)
     */
    private HealingResult attributeSwapHealing(String locator) {
        String value = LocatorUtils.LocatorParser.getValue(locator);
        String type = LocatorUtils.LocatorParser.getType(locator);
        
        // If using @id, try @name, @accessibility-id, etc.
        if (value.contains("@id=")) {
            String[] attributes = {"@name=", "@accessibility-id=", "@content-desc="};
            
            for (String attr : attributes) {
                String swapped = value.replace("@id=", attr);
                if (!swapped.equals(value)) {
                    String healedLocator = LocatorUtils.formatLocator(swapped, type);
                    return new HealingResult(true, healedLocator, "Layer1-AttrSwap", 0.70, 0);
                }
            }
        }
        
        return new HealingResult(false, null, "Layer1-AttrSwap", 0, 0);
    }
    
    /**
     * Cache a successful healing
     */
    private void cacheHealing(String original, String healed) {
        if (config.isPreprocessorCacheEnabled()) {
            healingCache.put(original, healed);
            logger.debug("Cached healing: {} -> {}", original, healed);
        }
    }
    
    /**
     * Clear cache
     */
    public void clearCache() {
        healingCache.clear();
        logger.info("Layer 1 cache cleared");
    }
    
    /**
     * Get cache statistics
     */
    public Map<String, Object> getCacheStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("size", healingCache.size());
        stats.put("maxSize", maxCacheSize);
        stats.put("hitRate", healingCache.size() + "/" + maxCacheSize);
        return stats;
    }
    
    /**
     * Check if pre-processor is enabled
     */
    public boolean isEnabled() {
        return config.isPreprocessorEnabled();
    }
    
    /**
     * Get timeout for this layer
     */
    public long getTimeoutMs() {
        return config.getPreprocessorTimeoutMs();
    }
}
