package com.healing.framework.metrics;

import com.google.gson.*;
import com.healing.framework.config.HealingConfig;
import com.healing.framework.models.HealingModels.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * Metrics Collector - Tracks healing events and generates reports
 */
public class MetricsCollector {
    private static final Logger logger = LoggerFactory.getLogger(MetricsCollector.class);
    private final HealingConfig config;
    private final List<HealingEvent> events;
    private final Map<String, LayerMetrics> layerMetrics;
    private final Gson gson;
    
    public MetricsCollector() {
        this.config = HealingConfig.getInstance();
        this.events = new CopyOnWriteArrayList<>();
        this.layerMetrics = new HashMap<>();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        
        // Initialize layer metrics
        layerMetrics.put("Layer1-PreProcessor", new LayerMetrics("Layer1-PreProcessor"));
        layerMetrics.put("Layer2-Healenium", new LayerMetrics("Layer2-Healenium"));
        layerMetrics.put("Layer3-Fallback", new LayerMetrics("Layer3-Fallback"));
    }
    
    /**
     * Record a healing event
     */
    public void recordEvent(HealingEvent event) {
        if (!config.isMetricsEnabled()) {
            return;
        }
        
        events.add(event);
        
        // Update layer metrics if healing succeeded
        if (event.isSuccess() && event.getLayer() != null) {
            LayerMetrics metrics = layerMetrics.get(event.getLayer());
            if (metrics != null) {
                metrics.recordAttempt(true, event.getDuration());
            }
        }
        
        logger.debug("Recorded healing event: {}", event);
    }
    
    /**
     * Get overall metrics
     */
    public HealingMetrics getMetrics() {
        HealingMetrics metrics = new HealingMetrics();
        
        int successCount = (int) events.stream().filter(HealingEvent::isSuccess).count();
        int failureCount = events.size() - successCount;
        long totalDuration = events.stream().mapToLong(HealingEvent::getDuration).sum();
        
        metrics.setTotalHealed(events.size());
        metrics.setSuccessfulHeals(successCount);
        metrics.setFailedHeals(failureCount);
        metrics.setTotalDuration(totalDuration);
        
        if (events.size() > 0) {
            metrics.setAverageDuration((double) totalDuration / events.size());
        }
        
        // Add layer metrics
        metrics.setLayerMetrics(new HashMap<>(layerMetrics));
        
        // Locator type statistics
        Map<String, Integer> typeStats = events.stream()
            .collect(Collectors.groupingBy(
                event -> extractLocatorType(event.getOriginalLocator()),
                Collectors.summingInt(e -> 1)
            ));
        metrics.setLocatorTypeStats(typeStats);
        
        return metrics;
    }
    
    /**
     * Extract locator type from locator string
     */
    private String extractLocatorType(String locator) {
        if (locator == null) return "unknown";
        if (locator.contains("~")) {
            return locator.split("~")[1];
        } else if (locator.startsWith("//")) {
            return "xpath";
        } else if (locator.contains("css=")) {
            return "css";
        }
        return "unknown";
    }
    
    /**
     * Generate HTML report
     */
    public void generateReports() {
        if (!config.isReportingEnabled()) {
            return;
        }
        
        try {
            String reportPath = config.getReportExportPath();
            
            // Skip if report path is null or empty
            if (reportPath == null || reportPath.isEmpty()) {
                logger.debug("Report path not configured, skipping report generation");
                return;
            }
            
            Path reportDir = Paths.get(reportPath);
            Files.createDirectories(reportDir);
            
            HealingMetrics metrics = getMetrics();
            
            // JSON Report
            if (config.isJsonExportEnabled()) {
                generateJsonReport(metrics, reportDir);
            }
            
            // HTML Report
            if (config.isHtmlExportEnabled()) {
                generateHtmlReport(metrics, reportDir);
            }
            
            logger.info("Reports generated at: {}", reportDir.toAbsolutePath());
            
        } catch (Exception e) {
            logger.error("Error generating reports: {}", e.getMessage());
        }
    }
    
    /**
     * Generate JSON report
     */
    private void generateJsonReport(HealingMetrics metrics, Path reportDir) throws Exception {
        JsonObject root = new JsonObject();
        
        // Summary
        JsonObject summary = new JsonObject();
        summary.addProperty("totalHealed", metrics.getTotalHealed());
        summary.addProperty("successfulHeals", metrics.getSuccessfulHeals());
        summary.addProperty("failedHeals", metrics.getFailedHeals());
        summary.addProperty("successRate", metrics.getSuccessRate());
        summary.addProperty("averageDuration", metrics.getAverageDuration());
        root.add("summary", summary);
        
        // Layer Metrics
        JsonObject layers = new JsonObject();
        for (Map.Entry<String, LayerMetrics> entry : metrics.getLayerMetrics().entrySet()) {
            LayerMetrics lm = entry.getValue();
            JsonObject layer = new JsonObject();
            layer.addProperty("attempts", lm.getAttempts());
            layer.addProperty("successes", lm.getSuccesses());
            layer.addProperty("successRate", lm.getSuccessRate());
            layer.addProperty("averageDuration", lm.getAverageDuration());
            layers.add(entry.getKey(), layer);
        }
        root.add("layers", layers);
        
        // Events
        JsonArray eventsArray = new JsonArray();
        for (HealingEvent event : events) {
            JsonObject eventJson = new JsonObject();
            eventJson.addProperty("testName", event.getTestName());
            eventJson.addProperty("originalLocator", event.getOriginalLocator());
            eventJson.addProperty("healedLocator", event.getHealedLocator());
            eventJson.addProperty("layer", event.getLayer());
            eventJson.addProperty("score", event.getScore());
            eventJson.addProperty("duration", event.getDuration());
            eventJson.addProperty("success", event.isSuccess());
            eventJson.addProperty("timestamp", event.getTimestamp().toString());
            eventsArray.add(eventJson);
        }
        root.add("events", eventsArray);
        
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Path jsonFile = reportDir.resolve("healing-report-" + timestamp + ".json");
        Files.writeString(jsonFile, gson.toJson(root));
        logger.info("JSON report saved: {}", jsonFile);
    }
    
    /**
     * Generate HTML report
     */
    private void generateHtmlReport(HealingMetrics metrics, Path reportDir) throws Exception {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n");
        html.append("<html>\n");
        html.append("<head>\n");
        html.append("  <title>Self-Healing Report</title>\n");
        html.append("  <style>\n");
        html.append("    body { font-family: Arial, sans-serif; margin: 20px; }\n");
        html.append("    .header { background-color: #4CAF50; color: white; padding: 20px; border-radius: 5px; }\n");
        html.append("    .metric { display: inline-block; width: 20%; text-align: center; margin: 10px; }\n");
        html.append("    .metric-value { font-size: 24px; font-weight: bold; color: #4CAF50; }\n");
        html.append("    .metric-label { font-size: 12px; color: #666; }\n");
        html.append("    table { border-collapse: collapse; width: 100%; margin-top: 20px; }\n");
        html.append("    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n");
        html.append("    th { background-color: #4CAF50; color: white; }\n");
        html.append("    .success { background-color: #d4edda; }\n");
        html.append("    .failure { background-color: #f8d7da; }\n");
        html.append("  </style>\n");
        html.append("</head>\n");
        html.append("<body>\n");
        
        // Header
        html.append("  <div class='header'>\n");
        html.append("    <h1>🔧 Self-Healing Test Automation Report</h1>\n");
        html.append("    <p>Generated: ").append(new Date()).append("</p>\n");
        html.append("  </div>\n");
        
        // Summary Metrics
        html.append("  <h2>Summary</h2>\n");
        html.append("  <div class='metric'>\n");
        html.append("    <div class='metric-value'>").append(metrics.getTotalHealed()).append("</div>\n");
        html.append("    <div class='metric-label'>Total Healed</div>\n");
        html.append("  </div>\n");
        
        html.append("  <div class='metric'>\n");
        html.append("    <div class='metric-value'>").append(metrics.getSuccessfulHeals()).append("</div>\n");
        html.append("    <div class='metric-label'>Successful</div>\n");
        html.append("  </div>\n");
        
        html.append("  <div class='metric'>\n");
        html.append("    <div class='metric-value'>").append(String.format("%.1f%%", metrics.getSuccessRate())).append("</div>\n");
        html.append("    <div class='metric-label'>Success Rate</div>\n");
        html.append("  </div>\n");
        
        html.append("  <div class='metric'>\n");
        html.append("    <div class='metric-value'>").append(String.format("%.0f", metrics.getAverageDuration())).append("ms</div>\n");
        html.append("    <div class='metric-label'>Avg Duration</div>\n");
        html.append("  </div>\n");
        
        // Layer Breakdown
        html.append("  <h2>Layer Performance</h2>\n");
        html.append("  <table>\n");
        html.append("    <tr><th>Layer</th><th>Attempts</th><th>Successes</th><th>Success Rate</th><th>Avg Duration</th></tr>\n");
        for (Map.Entry<String, LayerMetrics> entry : metrics.getLayerMetrics().entrySet()) {
            LayerMetrics lm = entry.getValue();
            html.append("    <tr>\n");
            html.append("      <td>").append(entry.getKey()).append("</td>\n");
            html.append("      <td>").append(lm.getAttempts()).append("</td>\n");
            html.append("      <td>").append(lm.getSuccesses()).append("</td>\n");
            html.append("      <td>").append(String.format("%.1f%%", lm.getSuccessRate())).append("</td>\n");
            html.append("      <td>").append(String.format("%.0f", lm.getAverageDuration())).append("ms</td>\n");
            html.append("    </tr>\n");
        }
        html.append("  </table>\n");
        
        // Recent Events
        html.append("  <h2>Recent Healing Events</h2>\n");
        html.append("  <table>\n");
        html.append("    <tr><th>Test</th><th>Original</th><th>Healed</th><th>Layer</th><th>Score</th><th>Status</th></tr>\n");
        events.stream().limit(20).forEach(event -> {
            String statusClass = event.isSuccess() ? "success" : "failure";
            String statusText = event.isSuccess() ? "✅ Success" : "❌ Failed";
            html.append("    <tr class='").append(statusClass).append("'>\n");
            html.append("      <td>").append(event.getTestName()).append("</td>\n");
            html.append("      <td>").append(truncate(event.getOriginalLocator(), 30)).append("</td>\n");
            html.append("      <td>").append(truncate(event.getHealedLocator(), 30)).append("</td>\n");
            html.append("      <td>").append(event.getLayer() != null ? event.getLayer() : "N/A").append("</td>\n");
            html.append("      <td>").append(String.format("%.2f", event.getScore())).append("</td>\n");
            html.append("      <td>").append(statusText).append("</td>\n");
            html.append("    </tr>\n");
        });
        html.append("  </table>\n");
        
        html.append("</body>\n");
        html.append("</html>\n");
        
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Path htmlFile = reportDir.resolve("healing-dashboard-" + timestamp + ".html");
        Files.writeString(htmlFile, html.toString());
        logger.info("HTML report saved: {}", htmlFile);
    }
    
    /**
     * Truncate string to max length
     */
    private String truncate(String str, int maxLength) {
        if (str == null) return "N/A";
        return str.length() > maxLength ? str.substring(0, maxLength - 3) + "..." : str;
    }
    
    /**
     * Get all events
     */
    public List<HealingEvent> getEvents() {
        return new ArrayList<>(events);
    }
    
    /**
     * Clear events
     */
    public void clearEvents() {
        events.clear();
        logger.info("Metrics cleared");
    }
}
