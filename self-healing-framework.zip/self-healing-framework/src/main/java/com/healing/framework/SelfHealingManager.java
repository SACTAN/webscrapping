package com.healing.framework;

import com.healing.framework.config.HealingConfig;
import com.healing.framework.layers.PreProcessorLayer;
import com.healing.framework.layers.HealeniumLayer;
import com.healing.framework.layers.FallbackLayer;
import com.healing.framework.models.HealingModels.*;
import com.healing.framework.metrics.MetricsCollector;
import com.healing.framework.registry.LocatorRegistry;
import org.openqa.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.*;

/**
 * Main Self-Healing Framework Manager
 * Orchestrates all three healing layers and metrics collection
 */
public class SelfHealingManager {
    private static final Logger logger = LoggerFactory.getLogger(SelfHealingManager.class);
    private static SelfHealingManager instance;
    
    private final HealingConfig config;
    private final PreProcessorLayer layer1;
    private final HealeniumLayer layer2;
    private final FallbackLayer layer3;
    private final MetricsCollector metricsCollector;
    private final LocatorRegistry registry;
    private final ExecutorService executorService;
    
    private SelfHealingManager() {
        this.config = HealingConfig.getInstance();
        this.layer1 = new PreProcessorLayer();
        this.layer2 = new HealeniumLayer();
        this.layer3 = new FallbackLayer();
        this.metricsCollector = new MetricsCollector();
        this.registry = new LocatorRegistry();
        this.executorService = Executors.newFixedThreadPool(5);
        
        logger.info("Self-Healing Framework initialized");
        logger.info("Config: {}", config);
    }
    
    /**
     * Get singleton instance
     */
    public static synchronized SelfHealingManager getInstance() {
        if (instance == null) {
            instance = new SelfHealingManager();
        }
        return instance;
    }
    
    /**
     * Main healing method - tries all three layers
     */
    public HealingResult healLocator(String originalLocator, WebDriver driver) {
        if (!config.isHealingEnabled()) {
            logger.warn("Healing is disabled");
            return new HealingResult(false, null, "Disabled", 0, 0);
        }
        
        long startTime = System.currentTimeMillis();
        HealingEvent event = new HealingEvent(getCurrentTestName(), originalLocator);
        
        try {
            logger.info("Starting to heal locator: {}", originalLocator);
            
            // Check registry for cached healing chains
            HealingResult registryResult = registry.findHealing(originalLocator);
            if (registryResult != null && registryResult.isHealed()) {
                logger.info("Found healing in registry: {}", registryResult.getHealedLocator());
                recordMetrics(event, registryResult);
                return registryResult;
            }
            
            // Get page source for analysis
            String pageSource = driver.getPageSource();
            
            // Execute healing layers based on mode
            String mode = config.getHealingMode();
            HealingResult result = null;
            
            if ("hybrid".equals(mode)) {
                result = tryHybridHealing(originalLocator, pageSource);
            } else if ("healenium-only".equals(mode)) {
                result = layer2.heal(originalLocator, pageSource);
            } else if ("custom-only".equals(mode)) {
                result = tryCustomHealing(originalLocator, pageSource);
            }
            
            if (result != null && result.isHealed()) {
                // Verify healing works
                if (verifyHealing(result.getHealedLocator(), driver)) {
                    logger.info("Healing verified: {}", result);
                    event.setHealedLocator(result.getHealedLocator());
                    event.setLayer(result.getLayer());
                    event.setScore(result.getScore());
                    event.setSuccess(true);
                    
                    // Save to registry
                    registry.saveHealing(originalLocator, result.getHealedLocator());
                    
                    recordMetrics(event, result);
                    return result;
                } else {
                    logger.warn("Healing verification failed: {}", result);
                    event.setSuccess(false);
                    event.setErrorMessage("Verification failed");
                }
            }
            
            event.setSuccess(false);
            event.setErrorMessage("No healing succeeded");
            recordMetrics(event, new HealingResult(false, null, "AllLayers", 0, 
                System.currentTimeMillis() - startTime));
            
            return new HealingResult(false, null, "AllLayers", 0, 
                System.currentTimeMillis() - startTime);
            
        } catch (Exception e) {
            logger.error("Error during healing: ", e);
            event.setSuccess(false);
            event.setErrorMessage(e.getMessage());
            recordMetrics(event, new HealingResult(false, null, "Error", 0, 
                System.currentTimeMillis() - startTime));
            throw e;
        }
    }
    
    /**
     * Hybrid mode: Try all layers sequentially
     */
    private HealingResult tryHybridHealing(String originalLocator, String pageSource) {
        // Layer 1: Pre-Processor
        if (layer1.isEnabled()) {
            logger.debug("Trying Layer 1: Pre-Processor");
            HealingResult result = layer1.heal(originalLocator, pageSource);
            if (result.isHealed()) {
                return result;
            }
        }
        
        // Layer 2: Healenium
        if (layer2.isEnabled()) {
            logger.debug("Trying Layer 2: Healenium");
            HealingResult result = layer2.heal(originalLocator, pageSource);
            if (result.isHealed()) {
                return result;
            }
        }
        
        // Layer 3: Fallback
        if (layer3.isEnabled()) {
            logger.debug("Trying Layer 3: Fallback");
            HealingResult result = layer3.heal(originalLocator, pageSource);
            if (result.isHealed()) {
                return result;
            }
        }
        
        return new HealingResult(false, null, "HybridMode", 0, 0);
    }
    
    /**
     * Custom-only mode: Layers 1 and 3
     */
    private HealingResult tryCustomHealing(String originalLocator, String pageSource) {
        // Layer 1
        if (layer1.isEnabled()) {
            HealingResult result = layer1.heal(originalLocator, pageSource);
            if (result.isHealed()) {
                return result;
            }
        }
        
        // Layer 3
        if (layer3.isEnabled()) {
            HealingResult result = layer3.heal(originalLocator, pageSource);
            if (result.isHealed()) {
                return result;
            }
        }
        
        return new HealingResult(false, null, "CustomMode", 0, 0);
    }
    
    /**
     * Verify that healing works by checking if element can be found
     */
    private boolean verifyHealing(String healedLocator, WebDriver driver) {
        try {
            // Try to find element with healed locator
            By by = parseLocator(healedLocator);
            WebElement element = driver.findElement(by);
            return element != null && element.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            logger.debug("Verification failed: Element not found with healed locator", e);
            return false;
        } catch (Exception e) {
            logger.debug("Verification error: {}", e.getMessage());
            return false;
        }
    }
    
    /**
     * Parse locator string and return By object
     */
    private By parseLocator(String locator) {
        String[] parts = locator.split("~");
        String value = parts[0];
        String type = parts.length > 1 ? parts[1] : "xpath";
        
        switch (type.toLowerCase()) {
            case "xpath":
                return By.xpath(value);
            case "css":
                return By.cssSelector(value);
            case "id":
                return By.id(value);
            case "name":
                return By.name(value);
            case "classname":
                return By.className(value);
            case "tagname":
                return By.tagName(value);
            case "linktext":
                return By.linkText(value);
            case "partiallinktext":
                return By.partialLinkText(value);
            case "accessibilityid":
                return By.xpath("//*[@accessibility-id='" + value + "']");
            default:
                return By.xpath(value);
        }
    }
    
    /**
     * Record metrics for this healing event
     */
    private void recordMetrics(HealingEvent event, HealingResult result) {
        event.setDuration(result.getDuration());
        metricsCollector.recordEvent(event);
    }
    
    /**
     * Get current test name
     */
    private String getCurrentTestName() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        for (StackTraceElement element : stackTrace) {
            if (element.getMethodName().startsWith("test")) {
                return element.getClassName() + "." + element.getMethodName();
            }
        }
        return "Unknown";
    }
    
    /**
     * Get metrics
     */
    public HealingMetrics getMetrics() {
        return metricsCollector.getMetrics();
    }
    
    /**
     * Get registry
     */
    public LocatorRegistry getRegistry() {
        return registry;
    }
    
    /**
     * Shutdown framework
     */
    public void shutdown() {
        logger.info("Shutting down Self-Healing Framework");
        executorService.shutdown();
        metricsCollector.generateReports();
        registry.saveRegistry();
    }
}
