package com.healing.framework.utils;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Locator parsing and manipulation utilities
 */
public class LocatorUtils {
    
    public enum LocatorType {
        XPATH("xpath"),
        CSS("css"),
        ID("id"),
        NAME("name"),
        CLASS_NAME("className"),
        TAG_NAME("tagName"),
        LINK_TEXT("linkText"),
        PARTIAL_LINK_TEXT("partialLinkText"),
        ACCESSIBILITY_ID("accessibilityid"),
        UNKNOWN("unknown");
        
        private final String value;
        
        LocatorType(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
        
        public static LocatorType fromString(String str) {
            if (str == null) return UNKNOWN;
            for (LocatorType type : LocatorType.values()) {
                if (type.value.equalsIgnoreCase(str)) {
                    return type;
                }
            }
            return UNKNOWN;
        }
    }
    
    /**
     * Parse locator string with format: "value~type"
     */
    public static class LocatorParser {
        
        public static Map<String, String> parse(String locator) {
            Map<String, String> result = new HashMap<>();
            
            if (locator == null || locator.isEmpty()) {
                result.put("type", LocatorType.UNKNOWN.getValue());
                result.put("value", "");
                return result;
            }
            
            // Format: "value~type"
            if (locator.contains("~")) {
                String[] parts = locator.split("~");
                result.put("value", parts[0]);
                result.put("type", parts.length > 1 ? parts[1] : LocatorType.XPATH.getValue());
            } else {
                // Guess type
                result.put("value", locator);
                result.put("type", guessType(locator));
            }
            
            return result;
        }
        
        public static String getValue(String locator) {
            return parse(locator).get("value");
        }
        
        public static String getType(String locator) {
            return parse(locator).get("type");
        }
        
        private static String guessType(String locator) {
            if (locator.startsWith("//")) return LocatorType.XPATH.getValue();
            if (locator.startsWith("[")) return LocatorType.XPATH.getValue();
            if (locator.contains("css=")) return LocatorType.CSS.getValue();
            return LocatorType.XPATH.getValue();
        }
    }
    
    /**
     * Simplify XPath expressions
     */
    public static class XPathSimplifier {
        
        /**
         * Remove predicates from XPath to create simpler versions
         */
        public static List<String> generateSimplifications(String xpath) {
            List<String> simplified = new ArrayList<>();
            simplified.add(xpath);
            
            // Remove all predicates
            String noPred = xpath.replaceAll("\\[.*?\\]", "");
            if (!noPred.equals(xpath)) {
                simplified.add(noPred);
            }
            
            // Keep only last element
            if (xpath.contains("/")) {
                String[] parts = xpath.split("/");
                String lastPart = parts[parts.length - 1];
                if (!lastPart.isEmpty()) {
                    simplified.add("//" + lastPart);
                    simplified.add("//" + lastPart.replaceAll("\\[.*?\\]", ""));
                }
            }
            
            return simplified;
        }
        
        /**
         * Extract element name from XPath
         */
        public static String extractElementName(String xpath) {
            if (xpath == null || xpath.isEmpty()) return "";
            
            // Handle //element[@attr='value']
            Pattern pattern = Pattern.compile("//([a-zA-Z0-9._-]+)");
            java.util.regex.Matcher matcher = pattern.matcher(xpath);
            if (matcher.find()) {
                String element = matcher.group(1);
                return element.split("\\[")[0]; // Remove predicates
            }
            
            return "";
        }
        
        /**
         * Extract predicates from XPath
         */
        public static List<String> extractPredicates(String xpath) {
            List<String> predicates = new ArrayList<>();
            Pattern pattern = Pattern.compile("\\[([^\\]]+)\\]");
            java.util.regex.Matcher matcher = pattern.matcher(xpath);
            
            while (matcher.find()) {
                predicates.add(matcher.group(1));
            }
            
            return predicates;
        }
    }
    
    /**
     * Case-insensitive variations
     */
    public static class CaseVariations {
        
        public static List<String> generate(String value) {
            List<String> variations = new ArrayList<>();
            variations.add(value);
            variations.add(value.toLowerCase());
            variations.add(value.toUpperCase());
            variations.add(capitalize(value));
            
            return variations;
        }
        
        private static String capitalize(String str) {
            if (str == null || str.isEmpty()) return str;
            return Character.toUpperCase(str.charAt(0)) + str.substring(1).toLowerCase();
        }
    }
    
    /**
     * Attribute utilities
     */
    public static class AttributeUtils {
        
        /**
         * Extract attribute value from XPath predicate
         */
        public static String extractAttributeValue(String predicate, String attributeName) {
            Pattern pattern = Pattern.compile("@" + attributeName + "\\s*=\\s*['\"]([^'\"]+)['\"]");
            java.util.regex.Matcher matcher = pattern.matcher(predicate);
            
            if (matcher.find()) {
                return matcher.group(1);
            }
            
            return null;
        }
        
        /**
         * Build XPath with attributes
         */
        public static String buildXPathWithAttributes(String elementName, 
                                                     Map<String, String> attributes) {
            StringBuilder xpath = new StringBuilder("//");
            xpath.append(elementName);
            
            for (Map.Entry<String, String> entry : attributes.entrySet()) {
                xpath.append("[@").append(entry.getKey()).append("='")
                     .append(entry.getValue()).append("']");
            }
            
            return xpath.toString();
        }
    }
    
    /**
     * Format locator with type suffix
     */
    public static String formatLocator(String value, LocatorType type) {
        return value + "~" + type.getValue();
    }
    
    public static String formatLocator(String value, String type) {
        return value + "~" + type;
    }
}
