package com.healing.framework.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

/**
 * Configuration manager for Self-Healing Framework
 * Loads and manages all configuration properties
 */
public class HealingConfig {
    private static final Logger logger = LoggerFactory.getLogger(HealingConfig.class);
    private static HealingConfig instance;
    private Properties config;
    private final Map<String, String> overrides = new HashMap<>();

    private HealingConfig() {
        loadConfiguration();
    }

    /**
     * Get singleton instance
     */
    public static synchronized HealingConfig getInstance() {
        if (instance == null) {
            instance = new HealingConfig();
        }
        return instance;
    }

    /**
     * Load configuration from properties file
     */
    private void loadConfiguration() {
        config = new Properties();
        try {
            String configPath = System.getProperty("healing.config.path", 
                "src/main/resources/healing-config.properties");
            
            File configFile = new File(configPath);
            if (configFile.exists()) {
                try (InputStream input = new FileInputStream(configFile)) {
                    config.load(input);
                    logger.info("Configuration loaded from: {}", configPath);
                }
            } else {
                logger.warn("Config file not found at: {}, using defaults", configPath);
            }
        } catch (Exception e) {
            logger.warn("Could not load config file, using defaults", e);
        }
    }

    /**
     * Get string property
     */
    public String getString(String key, String defaultValue) {
        if (overrides.containsKey(key)) {
            return overrides.get(key);
        }
        return config.getProperty(key, defaultValue);
    }

    /**
     * Get boolean property
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        if (overrides.containsKey(key)) {
            return Boolean.parseBoolean(overrides.get(key));
        }
        String value = config.getProperty(key);
        return value != null ? Boolean.parseBoolean(value) : defaultValue;
    }

    /**
     * Get integer property
     */
    public int getInt(String key, int defaultValue) {
        if (overrides.containsKey(key)) {
            try {
                return Integer.parseInt(overrides.get(key));
            } catch (NumberFormatException e) {
                logger.warn("Invalid int value for key: {}", key);
                return defaultValue;
            }
        }
        String value = config.getProperty(key);
        if (value != null) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                logger.warn("Invalid int value for key: {}", key);
            }
        }
        return defaultValue;
    }

    /**
     * Get long property
     */
    public long getLong(String key, long defaultValue) {
        if (overrides.containsKey(key)) {
            try {
                return Long.parseLong(overrides.get(key));
            } catch (NumberFormatException e) {
                logger.warn("Invalid long value for key: {}", key);
                return defaultValue;
            }
        }
        String value = config.getProperty(key);
        if (value != null) {
            try {
                return Long.parseLong(value);
            } catch (NumberFormatException e) {
                logger.warn("Invalid long value for key: {}", key);
            }
        }
        return defaultValue;
    }

    /**
     * Get double property
     */
    public double getDouble(String key, double defaultValue) {
        if (overrides.containsKey(key)) {
            try {
                return Double.parseDouble(overrides.get(key));
            } catch (NumberFormatException e) {
                logger.warn("Invalid double value for key: {}", key);
                return defaultValue;
            }
        }
        String value = config.getProperty(key);
        if (value != null) {
            try {
                return Double.parseDouble(value);
            } catch (NumberFormatException e) {
                logger.warn("Invalid double value for key: {}", key);
            }
        }
        return defaultValue;
    }

    /**
     * Set override value (useful for testing)
     */
    public void setOverride(String key, String value) {
        overrides.put(key, value);
    }

    /**
     * Reset overrides
     */
    public void resetOverrides() {
        overrides.clear();
    }

    // ==================== MASTER SETTINGS ====================

    public boolean isHealingEnabled() {
        return getBoolean("healing.enabled", true);
    }

    public String getHealingMode() {
        return getString("healing.mode", "hybrid");
    }

    public boolean isDebugEnabled() {
        return getBoolean("healing.debug", false);
    }

    // ==================== VIDEO RECORDING ====================

    public boolean isVideoRecordingEnabled() {
        return getBoolean("video.recording.enabled", false);
    }

    public boolean isVideoOnFailureOnly() {
        return getBoolean("video.recording.on.failure.only", true);
    }

    // ==================== LAYER 1: PRE-PROCESSOR ====================

    public boolean isPreprocessorEnabled() {
        return getBoolean("healing.preprocessor.enabled", true);
    }

    public long getPreprocessorTimeoutMs() {
        return getLong("healing.preprocessor.timeout.ms", 150);
    }

    public boolean isPreprocessorCacheEnabled() {
        return getBoolean("healing.preprocessor.cache.enabled", true);
    }

    public int getPreprocessorMaxCacheSize() {
        return getInt("healing.preprocessor.max.cache.size", 1000);
    }

    public String[] getQuickRules() {
        String rules = getString("healing.preprocessor.quick.rules", 
            "xpath_simplification,case_variation,attribute_swap,cache_lookup");
        return rules.split(",");
    }

    // ==================== LAYER 2: HEALENIUM ====================

    public boolean isHealeniumEnabled() {
        return getBoolean("healing.healenium.enabled", true);
    }

    public long getHealeniumTimeoutMs() {
        return getLong("healing.healenium.timeout.ms", 7000);
    }

    public double getHealeniumScoreThreshold() {
        return getDouble("healing.healenium.score.threshold", 0.6);
    }

    public int getHealeniumMaxCandidates() {
        return getInt("healing.healenium.max.candidates", 10);
    }

    public String getHealeniumServerUrl() {
        return getString("healenium.server.url", "http://localhost:8080");
    }

    public boolean isHealeniumServerEnabled() {
        return getBoolean("healenium.server.enabled", false);
    }

    // ==================== LAYER 3: FALLBACK ====================

    public boolean isFallbackEnabled() {
        return getBoolean("healing.fallback.enabled", true);
    }

    public long getFallbackTimeoutMs() {
        return getLong("healing.fallback.timeout.ms", 4000);
    }

    public boolean isPlatformSpecificFallbackEnabled() {
        return getBoolean("healing.fallback.platform.specific", true);
    }

    public boolean isTextSearchFallbackEnabled() {
        return getBoolean("healing.fallback.text.search", true);
    }

    public boolean isHierarchicalFallbackEnabled() {
        return getBoolean("healing.fallback.hierarchical", true);
    }

    // ==================== SCORING & WEIGHTS ====================

    public double getTextWeight() {
        return getDouble("healing.score.weight.text", 0.4);
    }

    public double getAttributeWeight() {
        return getDouble("healing.score.weight.attribute", 0.3);
    }

    public double getClassWeight() {
        return getDouble("healing.score.weight.class", 0.2);
    }

    public double getPositionWeight() {
        return getDouble("healing.score.weight.position", 0.1);
    }

    // ==================== HEALING ATTEMPTS ====================

    public int getMaxAttempts() {
        return getInt("healing.max.attempts", 5);
    }

    public long getRetryIntervalMs() {
        return getLong("healing.retry.interval.ms", 500);
    }

    // ==================== REGISTRY ====================

    public boolean isRegistryEnabled() {
        return getBoolean("healing.registry.enabled", true);
    }

    public boolean isRegistryAutoSaveEnabled() {
        return getBoolean("healing.registry.auto.save", true);
    }

    public String getRegistryPath() {
        return getString("healing.registry.path", "healing-registry.json");
    }

    public boolean isFallbackChainsEnabled() {
        return getBoolean("healing.registry.fallback.chains", true);
    }

    // ==================== METRICS ====================

    public boolean isMetricsEnabled() {
        return getBoolean("healing.metrics.enabled", true);
    }

    public boolean isMetricsPersistEnabled() {
        return getBoolean("healing.metrics.persist", true);
    }

    public String getMetricsDatabaseUrl() {
        return getString("healing.metrics.database.url", "jdbc:postgresql://localhost:5432/healing");
    }

    public String getMetricsDatabaseUser() {
        return getString("healing.metrics.database.user", "healing");
    }

    public String getMetricsDatabasePassword() {
        return getString("healing.metrics.database.password", "healing123");
    }

    // ==================== REPORTING ====================

    public boolean isReportingEnabled() {
        return getBoolean("healing.report.enabled", true);
    }

    public boolean isCombinedReportEnabled() {
        return getBoolean("healing.report.combined", true);
    }

    public String getReportDetailLevel() {
        return getString("healing.report.detail.level", "HIGH");
    }

    public boolean isJsonExportEnabled() {
        return getBoolean("healing.report.export.json", true);
    }

    public boolean isExcelExportEnabled() {
        return getBoolean("healing.report.export.excel", true);
    }

    public boolean isHtmlExportEnabled() {
        return getBoolean("healing.report.export.html", true);
    }

    public String getReportExportPath() {
        return getString("healing.report.export.path", "target/healing-reports/");
    }

    // ==================== DASHBOARD ====================

    public boolean isDashboardEnabled() {
        return getBoolean("healing.dashboard.enabled", true);
    }

    public boolean isDashboardAutoGenerateEnabled() {
        return getBoolean("healing.dashboard.auto.generate", true);
    }

    public long getDashboardRefreshInterval() {
        return getLong("healing.dashboard.refresh.interval", 5000);
    }

    // ==================== HEALTH MONITORING ====================

    public boolean isHealthMonitoringEnabled() {
        return getBoolean("healing.health.monitor.enabled", true);
    }

    public double getHealthAlertThreshold() {
        return getDouble("healing.health.alert.threshold", 0.6);
    }

    public long getHealthCheckIntervalMs() {
        return getLong("healing.health.check.interval.ms", 300000);
    }

    // ==================== PERFORMANCE ====================

    public boolean isParallelExecutionEnabled() {
        return getBoolean("healing.performance.parallel.execution", true);
    }

    public boolean isCacheWarmupEnabled() {
        return getBoolean("healing.performance.cache.warmup", true);
    }

    public boolean isPredictiveHealingEnabled() {
        return getBoolean("healing.performance.predictive.healing", true);
    }

    @Override
    public String toString() {
        return "HealingConfig{" +
                "healingEnabled=" + isHealingEnabled() +
                ", mode='" + getHealingMode() + '\'' +
                ", preprocessor=" + isPreprocessorEnabled() +
                ", healenium=" + isHealeniumEnabled() +
                ", fallback=" + isFallbackEnabled() +
                '}';
    }
}
