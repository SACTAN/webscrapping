package com.healing.framework.registry;

import com.google.gson.*;
import com.healing.framework.config.HealingConfig;
import com.healing.framework.models.HealingModels.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Locator Registry - Stores healing chains and locator mappings
 * Provides fast lookup for previously healed locators
 */
public class LocatorRegistry {
    private static final Logger logger = LoggerFactory.getLogger(LocatorRegistry.class);
    private final HealingConfig config;
    private final Map<String, HealingChain> registry;
    private final Gson gson;
    
    public LocatorRegistry() {
        this.config = HealingConfig.getInstance();
        this.registry = new LinkedHashMap<>();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        
        if (config.isRegistryEnabled()) {
            loadRegistry();
        }
    }
    
    /**
     * Healing chain represents multiple fallback locators for an original locator
     */
    public static class HealingChain {
        private String originalLocator;
        private List<HealingOption> options;
        private int successCount;
        private int failureCount;
        private long lastUsed;
        
        public HealingChain(String originalLocator) {
            this.originalLocator = originalLocator;
            this.options = new ArrayList<>();
            this.lastUsed = System.currentTimeMillis();
        }
        
        public void addOption(String locator, double confidence) {
            options.add(new HealingOption(locator, confidence));
            options.sort((a, b) -> Double.compare(b.confidence, a.confidence));
        }
        
        public HealingOption getBestOption() {
            return options.isEmpty() ? null : options.get(0);
        }
        
        public void recordSuccess() {
            successCount++;
            lastUsed = System.currentTimeMillis();
        }
        
        public void recordFailure() {
            failureCount++;
        }
        
        public double getSuccessRate() {
            int total = successCount + failureCount;
            return total == 0 ? 0 : (double) successCount / total;
        }
        
        // Getters
        public String getOriginalLocator() { return originalLocator; }
        public List<HealingOption> getOptions() { return options; }
        public int getSuccessCount() { return successCount; }
        public int getFailureCount() { return failureCount; }
        public long getLastUsed() { return lastUsed; }
        
        public static class HealingOption {
            public String locator;
            public double confidence;
            
            public HealingOption(String locator, double confidence) {
                this.locator = locator;
                this.confidence = confidence;
            }
        }
    }
    
    /**
     * Find healing for a locator in registry
     */
    public HealingResult findHealing(String originalLocator) {
        if (!config.isRegistryEnabled() || !config.isFallbackChainsEnabled()) {
            return null;
        }
        
        HealingChain chain = registry.get(originalLocator);
        if (chain == null) {
            return null;
        }
        
        HealingChain.HealingOption bestOption = chain.getBestOption();
        if (bestOption != null) {
            logger.debug("Found healing in registry for: {} -> {}", 
                originalLocator, bestOption.locator);
            return new HealingResult(true, bestOption.locator, "Registry", 
                bestOption.confidence, 0);
        }
        
        return null;
    }
    
    /**
     * Save successful healing to registry
     */
    public void saveHealing(String originalLocator, String healedLocator) {
        if (!config.isRegistryEnabled()) {
            return;
        }
        
        HealingChain chain = registry.computeIfAbsent(originalLocator, 
            HealingChain::new);
        
        // Check if option already exists
        boolean exists = chain.getOptions().stream()
            .anyMatch(opt -> opt.locator.equals(healedLocator));
        
        if (!exists) {
            chain.addOption(healedLocator, 0.9);
            logger.info("Saved healing to registry: {} -> {}", 
                originalLocator, healedLocator);
        }
        
        if (config.isRegistryAutoSaveEnabled()) {
            saveRegistry();
        }
    }
    
    /**
     * Load registry from JSON file
     */
    public void loadRegistry() {
        try {
            String registryPath = config.getRegistryPath();
            Path path = Paths.get(registryPath);
            
            if (!Files.exists(path)) {
                logger.info("Registry file not found: {}", registryPath);
                return;
            }
            
            String json = Files.readString(path);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            
            for (String key : root.keySet()) {
                JsonObject chainJson = root.getAsJsonObject(key);
                HealingChain chain = new HealingChain(key);
                
                JsonArray optionsJson = chainJson.getAsJsonArray("options");
                for (JsonElement optionElement : optionsJson) {
                    JsonObject optionJson = optionElement.getAsJsonObject();
                    chain.addOption(
                        optionJson.get("locator").getAsString(),
                        optionJson.get("confidence").getAsDouble()
                    );
                }
                
                registry.put(key, chain);
            }
            
            logger.info("Loaded {} healing chains from registry", registry.size());
            
        } catch (Exception e) {
            logger.warn("Failed to load registry: {}", e.getMessage());
        }
    }
    
    /**
     * Save registry to JSON file
     */
    public void saveRegistry() {
        if (!config.isRegistryEnabled()) {
            return;
        }
        
        try {
            String registryPath = config.getRegistryPath();
            
            // Skip if registry path is null or empty
            if (registryPath == null || registryPath.isEmpty() || registryPath.trim().isEmpty()) {
                logger.debug("Registry path not configured, skipping auto-save");
                return;
            }
            
            JsonObject root = new JsonObject();
            
            for (HealingChain chain : registry.values()) {
                JsonObject chainJson = new JsonObject();
                
                JsonArray optionsArray = new JsonArray();
                for (HealingChain.HealingOption option : chain.getOptions()) {
                    JsonObject optionJson = new JsonObject();
                    optionJson.addProperty("locator", option.locator);
                    optionJson.addProperty("confidence", option.confidence);
                    optionsArray.add(optionJson);
                }
                
                chainJson.add("options", optionsArray);
                chainJson.addProperty("successCount", chain.getSuccessCount());
                chainJson.addProperty("failureCount", chain.getFailureCount());
                chainJson.addProperty("successRate", chain.getSuccessRate());
                
                root.add(chain.getOriginalLocator(), chainJson);
            }
            
            Path path = Paths.get(registryPath.trim());
            Path parentDir = path.getParent();
            if (parentDir != null) {
                Files.createDirectories(parentDir);
            }
            Files.writeString(path, gson.toJson(root));
            
            logger.info("Saved registry with {} healing chains", registry.size());
            
        } catch (Exception e) {
            logger.error("Failed to save registry: {}", e.getMessage());
        }
    }
    
    /**
     * Get all healing chains
     */
    public Map<String, HealingChain> getAllChains() {
        return new HashMap<>(registry);
    }
    
    /**
     * Get statistics
     */
    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalChains", registry.size());
        
        int totalSuccesses = registry.values().stream()
            .mapToInt(HealingChain::getSuccessCount)
            .sum();
        int totalFailures = registry.values().stream()
            .mapToInt(HealingChain::getFailureCount)
            .sum();
        
        stats.put("totalSuccesses", totalSuccesses);
        stats.put("totalFailures", totalFailures);
        
        double overallSuccessRate = (totalSuccesses + totalFailures) == 0 ? 0 :
            (double) totalSuccesses / (totalSuccesses + totalFailures);
        stats.put("overallSuccessRate", overallSuccessRate);
        
        return stats;
    }
    
    /**
     * Clear registry
     */
    public void clear() {
        registry.clear();
        logger.info("Registry cleared");
    }
}
