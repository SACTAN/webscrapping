package com.healing.framework.utils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Similarity algorithms for element matching
 * Implements LCS, Levenshtein, Jaccard, and Cosine similarity
 */
public class SimilarityAlgorithms {
    
    /**
     * Longest Common Subsequence (LCS) - O(m*n)
     * Used for attribute and text matching
     */
    public static class LCS {
        
        public static double calculateSimilarity(String str1, String str2) {
            if (str1 == null || str2 == null) return 0.0;
            if (str1.isEmpty() && str2.isEmpty()) return 1.0;
            
            int lcsLength = getLCSLength(str1, str2);
            int maxLength = Math.max(str1.length(), str2.length());
            
            return maxLength == 0 ? 0 : (double) lcsLength / maxLength;
        }
        
        private static int getLCSLength(String str1, String str2) {
            int m = str1.length();
            int n = str2.length();
            int[][] dp = new int[m + 1][n + 1];
            
            for (int i = 1; i <= m; i++) {
                for (int j = 1; j <= n; j++) {
                    if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                        dp[i][j] = dp[i - 1][j - 1] + 1;
                    } else {
                        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                    }
                }
            }
            
            return dp[m][n];
        }

        public static String getLCS(String str1, String str2) {
            int m = str1.length();
            int n = str2.length();
            int[][] dp = new int[m + 1][n + 1];
            
            for (int i = 1; i <= m; i++) {
                for (int j = 1; j <= n; j++) {
                    if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                        dp[i][j] = dp[i - 1][j - 1] + 1;
                    } else {
                        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                    }
                }
            }
            
            // Backtrack to find LCS string
            StringBuilder lcs = new StringBuilder();
            int i = m, j = n;
            while (i > 0 && j > 0) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    lcs.insert(0, str1.charAt(i - 1));
                    i--;
                    j--;
                } else if (dp[i - 1][j] > dp[i][j - 1]) {
                    i--;
                } else {
                    j--;
                }
            }
            
            return lcs.toString();
        }
    }
    
    /**
     * Levenshtein Distance - Edit Distance - O(m*n)
     * Minimum number of single-character edits (insert, delete, replace)
     */
    public static class LevenshteinDistance {
        
        public static int calculateDistance(String str1, String str2) {
            if (str1 == null) str1 = "";
            if (str2 == null) str2 = "";
            if (str1.equals(str2)) return 0;
            
            int m = str1.length();
            int n = str2.length();
            
            int[][] dp = new int[m + 1][n + 1];
            
            for (int i = 0; i <= m; i++) dp[i][0] = i;
            for (int j = 0; j <= n; j++) dp[0][j] = j;
            
            for (int i = 1; i <= m; i++) {
                for (int j = 1; j <= n; j++) {
                    if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                        dp[i][j] = dp[i - 1][j - 1];
                    } else {
                        dp[i][j] = 1 + Math.min(
                            Math.min(dp[i - 1][j], dp[i][j - 1]), 
                            dp[i - 1][j - 1]
                        );
                    }
                }
            }
            
            return dp[m][n];
        }
        
        public static double calculateSimilarity(String str1, String str2) {
            if (str1 == null || str2 == null) return 0.0;
            if (str1.isEmpty() && str2.isEmpty()) return 1.0;
            
            int distance = calculateDistance(str1, str2);
            int maxLength = Math.max(str1.length(), str2.length());
            
            return maxLength == 0 ? 0 : 1.0 - (double) distance / maxLength;
        }
    }
    
    /**
     * Jaccard Similarity - Set-based similarity
     * Used for class matching and attribute sets
     */
    public static class JaccardSimilarity {
        
        public static double calculate(Set<String> set1, Set<String> set2) {
            if (set1 == null) set1 = new HashSet<>();
            if (set2 == null) set2 = new HashSet<>();
            if (set1.isEmpty() && set2.isEmpty()) return 1.0;
            
            Set<String> intersection = new HashSet<>(set1);
            intersection.retainAll(set2);
            
            Set<String> union = new HashSet<>(set1);
            union.addAll(set2);
            
            return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
        }
        
        public static double calculateFromStrings(String str1, String str2) {
            Set<String> set1 = tokenize(str1);
            Set<String> set2 = tokenize(str2);
            return calculate(set1, set2);
        }
        
        private static Set<String> tokenize(String str) {
            if (str == null || str.isEmpty()) return new HashSet<>();
            return new HashSet<>(Arrays.asList(str.split("\\s+")));
        }
    }
    
    /**
     * Cosine Similarity - Vector-based similarity
     * Used for text and attribute matching
     */
    public static class CosineSimilarity {
        
        public static double calculate(String str1, String str2) {
            if (str1 == null || str2 == null) return 0.0;
            if (str1.isEmpty() && str2.isEmpty()) return 1.0;
            
            Map<String, Integer> vector1 = toVector(str1);
            Map<String, Integer> vector2 = toVector(str2);
            
            double dotProduct = 0;
            double norm1 = 0;
            double norm2 = 0;
            
            // Dot product
            for (String key : vector1.keySet()) {
                int count = vector1.get(key);
                dotProduct += count * vector2.getOrDefault(key, 0);
            }
            
            // Norms
            for (int count : vector1.values()) {
                norm1 += count * count;
            }
            for (int count : vector2.values()) {
                norm2 += count * count;
            }
            
            double denominator = Math.sqrt(norm1) * Math.sqrt(norm2);
            return denominator == 0 ? 0 : dotProduct / denominator;
        }
        
        private static Map<String, Integer> toVector(String str) {
            Map<String, Integer> vector = new HashMap<>();
            String[] words = str.toLowerCase().split("\\W+");
            
            for (String word : words) {
                if (!word.isEmpty()) {
                    vector.put(word, vector.getOrDefault(word, 0) + 1);
                }
            }
            
            return vector;
        }
    }
    
    /**
     * Hamming Distance - for fixed-length strings
     * Count positions at which characters differ
     */
    public static class HammingDistance {
        
        public static int calculate(String str1, String str2) {
            if (str1 == null || str2 == null) return 0;
            if (str1.length() != str2.length()) {
                throw new IllegalArgumentException("Strings must be equal length");
            }
            
            int distance = 0;
            for (int i = 0; i < str1.length(); i++) {
                if (str1.charAt(i) != str2.charAt(i)) {
                    distance++;
                }
            }
            
            return distance;
        }
        
        public static double calculateSimilarity(String str1, String str2) {
            if (str1 == null || str2 == null) return 0.0;
            if (str1.length() != str2.length()) return 0.0;
            if (str1.isEmpty()) return 1.0;
            
            int distance = calculate(str1, str2);
            return 1.0 - (double) distance / str1.length();
        }
    }
    
    /**
     * Fuzzy Matching - allows for typos and near-matches
     */
    public static class FuzzyMatcher {
        
        public static boolean matches(String str1, String str2, double threshold) {
            double similarity = LevenshteinDistance.calculateSimilarity(str1, str2);
            return similarity >= threshold;
        }
        
        public static List<String> findMatches(String query, List<String> candidates, double threshold) {
            return candidates.stream()
                .filter(candidate -> matches(query, candidate, threshold))
                .sorted((a, b) -> Double.compare(
                    LevenshteinDistance.calculateSimilarity(query, b),
                    LevenshteinDistance.calculateSimilarity(query, a)
                ))
                .collect(Collectors.toList());
        }
    }
    
    /**
     * Composite similarity scoring with weighted metrics
     */
    public static class CompositeSimilarity {
        
        public static double calculate(
            String original,
            String candidate,
            double textWeight,
            double attributeWeight) {
            
            double textScore = LevenshteinDistance.calculateSimilarity(original, candidate);
            double attributeScore = JaccardSimilarity.calculateFromStrings(original, candidate);
            
            double totalWeight = textWeight + attributeWeight;
            if (totalWeight == 0) return 0;
            
            return (textScore * textWeight + attributeScore * attributeWeight) / totalWeight;
        }
    }
}
