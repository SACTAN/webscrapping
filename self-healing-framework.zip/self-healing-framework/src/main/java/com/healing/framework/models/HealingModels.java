package com.healing.framework.models;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Core data models for the Self-Healing Framework
 */
public class HealingModels {

    /**
     * Represents a locator with all metadata
     */
    public static class Locator {
        private String original;
        private String healed;
        private String type; // xpath, css, id, accessibility-id
        private double confidenceScore;
        private LocalDateTime lastUsed;
        private int successCount;
        private int failureCount;
        private String platform; // android, ios, web
        private Map<String, String> attributes;

        public Locator(String original, String type) {
            this.original = original;
            this.type = type;
            this.attributes = new HashMap<>();
            this.lastUsed = LocalDateTime.now();
            this.successCount = 0;
            this.failureCount = 0;
        }

        // Getters and Setters
        public String getOriginal() { return original; }
        public void setOriginal(String original) { this.original = original; }

        public String getHealed() { return healed; }
        public void setHealed(String healed) { this.healed = healed; }

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public double getConfidenceScore() { return confidenceScore; }
        public void setConfidenceScore(double confidenceScore) { 
            this.confidenceScore = confidenceScore; 
        }

        public LocalDateTime getLastUsed() { return lastUsed; }
        public void setLastUsed(LocalDateTime lastUsed) { this.lastUsed = lastUsed; }

        public int getSuccessCount() { return successCount; }
        public void setSuccessCount(int successCount) { this.successCount = successCount; }

        public int getFailureCount() { return failureCount; }
        public void setFailureCount(int failureCount) { this.failureCount = failureCount; }

        public String getPlatform() { return platform; }
        public void setPlatform(String platform) { this.platform = platform; }

        public Map<String, String> getAttributes() { return attributes; }
        public void setAttributes(Map<String, String> attributes) { this.attributes = attributes; }

        public double getSuccessRate() {
            int total = successCount + failureCount;
            return total == 0 ? 0 : (double) successCount / total;
        }

        public void recordSuccess() {
            this.successCount++;
            this.lastUsed = LocalDateTime.now();
        }

        public void recordFailure() {
            this.failureCount++;
        }

        @Override
        public String toString() {
            return "Locator{" +
                    "original='" + original + '\'' +
                    ", healed='" + healed + '\'' +
                    ", type='" + type + '\'' +
                    ", score=" + confidenceScore +
                    ", successRate=" + getSuccessRate() +
                    '}';
        }
    }

    /**
     * Represents a healing event with details
     */
    public static class HealingEvent {
        private String testName;
        private String originalLocator;
        private String healedLocator;
        private String layer; // Layer1, Layer2, Layer3
        private double score;
        private long duration;
        private boolean success;
        private LocalDateTime timestamp;
        private String errorMessage;
        private String platform;
        private Map<String, Object> metadata;

        public HealingEvent(String testName, String originalLocator) {
            this.testName = testName;
            this.originalLocator = originalLocator;
            this.timestamp = LocalDateTime.now();
            this.metadata = new HashMap<>();
        }

        // Getters and Setters
        public String getTestName() { return testName; }
        public void setTestName(String testName) { this.testName = testName; }

        public String getOriginalLocator() { return originalLocator; }
        public void setOriginalLocator(String originalLocator) { 
            this.originalLocator = originalLocator; 
        }

        public String getHealedLocator() { return healedLocator; }
        public void setHealedLocator(String healedLocator) { 
            this.healedLocator = healedLocator; 
        }

        public String getLayer() { return layer; }
        public void setLayer(String layer) { this.layer = layer; }

        public double getScore() { return score; }
        public void setScore(double score) { this.score = score; }

        public long getDuration() { return duration; }
        public void setDuration(long duration) { this.duration = duration; }

        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }

        public LocalDateTime getTimestamp() { return timestamp; }
        public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

        public String getErrorMessage() { return errorMessage; }
        public void setErrorMessage(String errorMessage) { 
            this.errorMessage = errorMessage; 
        }

        public String getPlatform() { return platform; }
        public void setPlatform(String platform) { this.platform = platform; }

        public Map<String, Object> getMetadata() { return metadata; }
        public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }

        @Override
        public String toString() {
            return "HealingEvent{" +
                    "test='" + testName + '\'' +
                    ", layer='" + layer + '\'' +
                    ", success=" + success +
                    ", score=" + score +
                    ", duration=" + duration + "ms" +
                    '}';
        }
    }

    /**
     * Represents healing metrics and statistics
     */
    public static class HealingMetrics {
        private int totalHealed;
        private int successfulHeals;
        private int failedHeals;
        private long totalDuration;
        private double averageDuration;
        private Map<String, LayerMetrics> layerMetrics;
        private Map<String, Integer> locatorTypeStats;
        private LocalDateTime lastUpdate;

        public HealingMetrics() {
            this.layerMetrics = new HashMap<>();
            this.locatorTypeStats = new HashMap<>();
            this.lastUpdate = LocalDateTime.now();
        }

        // Getters and Setters
        public int getTotalHealed() { return totalHealed; }
        public void setTotalHealed(int totalHealed) { this.totalHealed = totalHealed; }

        public int getSuccessfulHeals() { return successfulHeals; }
        public void setSuccessfulHeals(int successfulHeals) { 
            this.successfulHeals = successfulHeals; 
        }

        public int getFailedHeals() { return failedHeals; }
        public void setFailedHeals(int failedHeals) { this.failedHeals = failedHeals; }

        public long getTotalDuration() { return totalDuration; }
        public void setTotalDuration(long totalDuration) { this.totalDuration = totalDuration; }

        public double getAverageDuration() { return averageDuration; }
        public void setAverageDuration(double averageDuration) { 
            this.averageDuration = averageDuration; 
        }

        public Map<String, LayerMetrics> getLayerMetrics() { return layerMetrics; }
        public void setLayerMetrics(Map<String, LayerMetrics> layerMetrics) { 
            this.layerMetrics = layerMetrics; 
        }

        public Map<String, Integer> getLocatorTypeStats() { return locatorTypeStats; }
        public void setLocatorTypeStats(Map<String, Integer> locatorTypeStats) { 
            this.locatorTypeStats = locatorTypeStats; 
        }

        public LocalDateTime getLastUpdate() { return lastUpdate; }
        public void setLastUpdate(LocalDateTime lastUpdate) { this.lastUpdate = lastUpdate; }

        public double getSuccessRate() {
            return totalHealed == 0 ? 0 : (double) successfulHeals / totalHealed * 100;
        }

        public void recordHeal(boolean success, long duration) {
            totalHealed++;
            totalDuration += duration;
            averageDuration = (double) totalDuration / totalHealed;
            
            if (success) {
                successfulHeals++;
            } else {
                failedHeals++;
            }
            lastUpdate = LocalDateTime.now();
        }
    }

    /**
     * Metrics for individual layer
     */
    public static class LayerMetrics {
        private String layerName;
        private int attempts;
        private int successes;
        private long totalDuration;
        private double averageDuration;

        public LayerMetrics(String layerName) {
            this.layerName = layerName;
            this.attempts = 0;
            this.successes = 0;
            this.totalDuration = 0;
        }

        public void recordAttempt(boolean success, long duration) {
            attempts++;
            totalDuration += duration;
            if (success) successes++;
            this.averageDuration = (double) totalDuration / attempts;
        }

        public double getSuccessRate() {
            return attempts == 0 ? 0 : (double) successes / attempts * 100;
        }

        // Getters
        public String getLayerName() { return layerName; }
        public int getAttempts() { return attempts; }
        public int getSuccesses() { return successes; }
        public long getTotalDuration() { return totalDuration; }
        public double getAverageDuration() { return averageDuration; }
    }

    /**
     * Result of a healing attempt
     */
    public static class HealingResult {
        private boolean healed;
        private String healedLocator;
        private String layer;
        private double score;
        private long duration;
        private String message;

        public HealingResult(boolean healed, String healedLocator, String layer, 
                            double score, long duration) {
            this.healed = healed;
            this.healedLocator = healedLocator;
            this.layer = layer;
            this.score = score;
            this.duration = duration;
        }

        public boolean isHealed() { return healed; }
        public String getHealedLocator() { return healedLocator; }
        public String getLayer() { return layer; }
        public double getScore() { return score; }
        public long getDuration() { return duration; }
        public void setDuration(long duration) { this.duration = duration; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }

        @Override
        public String toString() {
            return "HealingResult{" +
                    "healed=" + healed +
                    ", layer='" + layer + '\'' +
                    ", score=" + score +
                    ", duration=" + duration + "ms" +
                    ", locator='" + healedLocator + '\'' +
                    '}';
        }
    }

    /**
     * Element candidate for healing
     */
    public static class ElementCandidate {
        private String locator;
        private double similarityScore;
        private Map<String, String> attributes;
        private String text;
        private int position;

        public ElementCandidate(String locator, double score) {
            this.locator = locator;
            this.similarityScore = score;
            this.attributes = new HashMap<>();
        }

        public String getLocator() { return locator; }
        public double getSimilarityScore() { return similarityScore; }
        public void setSimilarityScore(double similarityScore) { 
            this.similarityScore = similarityScore; 
        }
        public Map<String, String> getAttributes() { return attributes; }
        public String getText() { return text; }
        public void setText(String text) { this.text = text; }
        public int getPosition() { return position; }
        public void setPosition(int position) { this.position = position; }

        @Override
        public String toString() {
            return "ElementCandidate{" +
                    "locator='" + locator + '\'' +
                    ", score=" + similarityScore +
                    ", text='" + text + '\'' +
                    '}';
        }
    }
}
