package com.healing.framework.layers;

import com.healing.framework.config.HealingConfig;
import com.healing.framework.models.HealingModels.*;
import com.healing.framework.utils.SimilarityAlgorithms;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Layer 3: Custom Fallback Engine
 * Advanced platform-specific strategies and fallback mechanisms
 * Expected success rate: 15-25%
 * Execution time: 1-4 seconds
 */
public class FallbackLayer {
    private static final Logger logger = LoggerFactory.getLogger(FallbackLayer.class);
    private final HealingConfig config;
    
    public FallbackLayer() {
        this.config = HealingConfig.getInstance();
    }
    
    /**
     * Execute Layer 3 fallback healing strategies
     */
    public HealingResult heal(String originalLocator, String pageSource) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.debug("Layer 3: Starting fallback healing for: {}", originalLocator);
            
            // Strategy 1: Platform-Specific Patterns
            if (config.isPlatformSpecificFallbackEnabled()) {
                HealingResult platformResult = platformSpecificHealing(originalLocator);
                if (platformResult.isHealed()) {
                    platformResult.setDuration(System.currentTimeMillis() - startTime);
                    logger.info("Layer 3: Platform-specific healing successful");
                    return platformResult;
                }
            }
            
            // Strategy 2: Text-Based Search
            if (config.isTextSearchFallbackEnabled()) {
                HealingResult textResult = textBasedHealing(originalLocator, pageSource);
                if (textResult.isHealed()) {
                    textResult.setDuration(System.currentTimeMillis() - startTime);
                    logger.info("Layer 3: Text-based healing successful");
                    return textResult;
                }
            }
            
            // Strategy 3: Hierarchical Search
            if (config.isHierarchicalFallbackEnabled()) {
                HealingResult hierResult = hierarchicalHealing(originalLocator);
                if (hierResult.isHealed()) {
                    hierResult.setDuration(System.currentTimeMillis() - startTime);
                    logger.info("Layer 3: Hierarchical healing successful");
                    return hierResult;
                }
            }
            
            // No healing found
            HealingResult noHeal = new HealingResult(false, null, "Layer3-Fallback", 0,
                System.currentTimeMillis() - startTime);
            noHeal.setMessage("No fallback strategy succeeded");
            logger.debug("Layer 3: No fallback strategy succeeded for: {}", originalLocator);
            return noHeal;
            
        } catch (Exception e) {
            logger.error("Layer 3: Error during healing", e);
            return new HealingResult(false, null, "Layer3-Fallback", 0,
                System.currentTimeMillis() - startTime);
        }
    }
    
    /**
     * Strategy 1: Platform-Specific Pattern Matching
     * Web UI focused - handles XPath and CSS patterns
     */
    private HealingResult platformSpecificHealing(String originalLocator) {
        // Web patterns - PRIORITIZED
        if (originalLocator.contains("css=") || originalLocator.contains("xpath") || 
            originalLocator.contains("/") || originalLocator.contains("@")) {
            HealingResult webHealing = handleWebPattern(originalLocator);
            if (webHealing.isHealed()) {
                return webHealing;
            }
        }
        
        // XPath to CSS conversion for web
        if (originalLocator.contains("/") || originalLocator.contains("@")) {
            HealingResult cssHealing = convertXPathToCss(originalLocator);
            if (cssHealing.isHealed()) {
                return cssHealing;
            }
        }
        
        return new HealingResult(false, null, "Layer3-WebPlatform", 0, 0);
    }
    
    /**
     * Convert XPath to CSS selector for web healing
     */
    private HealingResult convertXPathToCss(String locator) {
        logger.debug("Layer 3: Attempting XPath to CSS conversion");
        
        // Simple XPath to CSS conversions
        if (locator.contains("@id=")) {
            String id = extractValue(locator, "id");
            if (id != null && !id.isEmpty()) {
                String cssSelectorLocator = "#" + id + "~css";
                return new HealingResult(true, cssSelectorLocator, "Layer3-XPathToCss-Id", 0.80, 0);
            }
        }
        
        // Class-based CSS selector
        if (locator.contains("@class=")) {
            String cssClass = extractValue(locator, "class");
            if (cssClass != null && !cssClass.isEmpty()) {
                String cssSelectorLocator = "." + cssClass.split(" ")[0] + "~css";
                return new HealingResult(true, cssSelectorLocator, "Layer3-XPathToCss-Class", 0.76, 0);
            }
        }
        
        // Type selector for input elements
        if (locator.contains("input") && locator.contains("@type=")) {
            String typeValue = extractValue(locator, "type");
            if (typeValue != null && !typeValue.isEmpty()) {
                String cssSelectorLocator = "input[type='" + typeValue + "']~css";
                return new HealingResult(true, cssSelectorLocator, "Layer3-XPathToCss-Input", 0.74, 0);
            }
        }
        
        return new HealingResult(false, null, "Layer3-XPathToCss", 0, 0);
    }
    
    /**
     * Handle Web-specific healing
     */
    private HealingResult handleWebPattern(String locator) {
        logger.debug("Layer 3: Attempting Web pattern healing");
        
        // If CSS selector, try to convert to XPath
        if (locator.contains("css=")) {
            String cssSelector = locator.replace("css=", "");
            String xpathHealing = convertCSSToXPath(cssSelector);
            if (!xpathHealing.isEmpty()) {
                return new HealingResult(true, xpathHealing, "Layer3-CSSToXPath", 0.75, 0);
            }
        }
        
        // If link text, try partial link text
        if (locator.contains("linkText=")) {
            String partialHealing = locator.replace("linkText=", "partialLinkText=");
            return new HealingResult(true, partialHealing, "Layer3-PartialLink", 0.70, 0);
        }
        
        return new HealingResult(false, null, "Layer3-Web", 0, 0);
    }
    
    /**
     * Strategy 2: Text-Based Search with Fuzzy Matching
     */
    private HealingResult textBasedHealing(String originalLocator, String pageSource) {
        logger.debug("Layer 3: Attempting text-based healing");
        
        // Extract text from original locator if available
        String textContent = extractValue(originalLocator, "text");
        if (textContent == null || textContent.isEmpty()) {
            return new HealingResult(false, null, "Layer3-TextBased", 0, 0);
        }
        
        // Try exact text match
        String exactHealing = "//*[contains(text(), '" + textContent + "')]";
        return new HealingResult(true, exactHealing, "Layer3-ExactText", 0.75, 0);
    }
    
    /**
     * Strategy 3: Hierarchical Search
     * Navigate parent/child relationships
     */
    private HealingResult hierarchicalHealing(String originalLocator) {
        logger.debug("Layer 3: Attempting hierarchical healing");
        
        // Simplify by removing nested predicates
        String simplified = originalLocator.replaceAll("\\[.*?\\].*?\\[.*?\\]", "[*]");
        if (!simplified.equals(originalLocator)) {
            return new HealingResult(true, simplified, "Layer3-Hierarchical", 0.68, 0);
        }
        
        // Use parent element as fallback
        if (originalLocator.contains("/")) {
            String[] parts = originalLocator.split("/");
            if (parts.length > 2) {
                StringBuilder parent = new StringBuilder();
                for (int i = 0; i < parts.length - 1; i++) {
                    parent.append(parts[i]).append("/");
                }
                String parentHealing = parent.toString().replaceAll("/$", "");
                return new HealingResult(true, parentHealing, "Layer3-Parent", 0.60, 0);
            }
        }
        
        return new HealingResult(false, null, "Layer3-Hierarchical", 0, 0);
    }
    
    /**
     * Convert CSS selector to XPath (simplified)
     */
    private String convertCSSToXPath(String css) {
        // Very simplified conversion
        // In production, use a proper CSS to XPath converter
        
        if (css.startsWith(".")) {
            return "//*[contains(@class, '" + css.substring(1) + "')]";
        } else if (css.startsWith("#")) {
            return "//*[@id='" + css.substring(1) + "']";
        } else {
            return "//" + css;
        }
    }
    
    /**
     * Extract value from locator attribute
     * Pattern: @attributeName='value' or @attributeName="value"
     */
    private String extractValue(String locator, String attributeName) {
        Pattern pattern = Pattern.compile("@" + attributeName + "\\s*=\\s*['\"]([^'\"]+)['\"]");
        java.util.regex.Matcher matcher = pattern.matcher(locator);
        
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }
    
    /**
     * Check if fallback layer is enabled
     */
    public boolean isEnabled() {
        return config.isFallbackEnabled();
    }
    
    /**
     * Get timeout for this layer
     */
    public long getTimeoutMs() {
        return config.getFallbackTimeoutMs();
    }
}
